package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.InsuranceRequest;
import com.recyclexbackend.dto.response.InsuranceResponse;
import com.recyclexbackend.entity.Insurance;
import com.recyclexbackend.entity.Patient;
import com.recyclexbackend.entity.Payer;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.InsuranceRepository;
import com.recyclexbackend.repository.PatientRepository;
import com.recyclexbackend.repository.PayerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InsuranceService {

    private final InsuranceRepository insuranceRepository;
    private final PatientRepository patientRepository;
    private final PayerRepository payerRepository;
    private final AuditLogService auditLogService;

    public InsuranceResponse addInsurance(InsuranceRequest request, Long createdBy) {
    	 
        Patient patient = patientRepository
                .findByPatientIdAndIsDeletedFalse(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));
     
        Payer payer = payerRepository
                .findByPayerName(request.getPayerName())
                .orElseGet(() -> payerRepository.save(new Payer(request.getPayerName())));
     
        if (insuranceRepository.findByPolicyNumber(request.getPolicyNumber()).isPresent()) {
            throw new BadRequestException("Policy number already exists: " + request.getPolicyNumber());
        }
        
        if(insuranceRepository.existsByPatientPatientId(request.getPatientId())) {
        	    throw new RuntimeException("Insurance already exists for this patient");
        }
     
        Insurance insurance = new Insurance();
        insurance.setPatient(patient);
        insurance.setPayer(payer);
        insurance.setPolicyNumber(request.getPolicyNumber());
        insurance.setCoverageDetails(request.getCoverageDetails());
        insurance.setCoverageLimit(request.getCoverageLimit());
        insurance.setEligibilityStatus(request.getEligibilityStatus());
        insurance.setCreatedAt(LocalDateTime.now());
     
        Insurance saved = insuranceRepository.save(insurance);
     
        return toResponse(saved);
    }

    public List<InsuranceResponse> getInsuranceByPatient(Long patientId) {
        return insuranceRepository.findByPatient_PatientIdAndIsDeletedFalse(patientId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public InsuranceResponse getById(Long id) {
        Insurance insurance = insuranceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Insurance not found: " + id));
        return toResponse(insurance);
    }

    public InsuranceResponse toResponse(Insurance i) {
        InsuranceResponse r = new InsuranceResponse();
        r.setInsuranceId(i.getInsuranceId());
        r.setPatientId(i.getPatient().getPatientId());
        r.setPatientName(i.getPatient().getName());
        r.setPayerId(i.getPayer().getPayerId());
        r.setPayerName(i.getPayer().getPayerName());
        r.setPolicyNumber(i.getPolicyNumber());
        r.setCoverageDetails(i.getCoverageDetails());
        r.setCoverageLimit(i.getCoverageLimit());
        r.setEligibilityStatus(i.getEligibilityStatus());
        r.setCreatedAt(i.getCreatedAt());
        return r;
    }
}