package com.recyclexbackend.service;

import java.math.BigDecimal;

import java.time.LocalDateTime;

import java.util.ArrayList;

import java.util.List;

import org.springframework.stereotype.Service;

import com.recyclexbackend.entity.ChargeEntry;

import com.recyclexbackend.entity.Claim;

import com.recyclexbackend.entity.ClaimEdit;

import com.recyclexbackend.entity.Insurance;

import com.recyclexbackend.repository.ChargeEntryRepository;

import com.recyclexbackend.repository.ClaimEditRepository;

import com.recyclexbackend.repository.IcdCptMappingRepository;

import com.recyclexbackend.repository.InsuranceRepository;

import lombok.RequiredArgsConstructor;

@Service

@RequiredArgsConstructor

public class ClaimScrubberService {

	private final ChargeEntryRepository chargeEntryRepository;

	private final InsuranceRepository insuranceRepository;

	private final ClaimEditRepository claimEditRepository;

	private final IcdCptMappingRepository icdCptMappingRepository;

	public List<ClaimEdit> scrubClaim(Claim claim) {

		List<ClaimEdit> edits = new ArrayList<>();

		// Rule 1: Check charges exist

		List<ChargeEntry> charges = chargeEntryRepository.findByEncounter_EncounterId(

				claim.getEncounter().getEncounterId());

		if (charges.isEmpty()) {

			edits.add(buildEdit(claim, "MISSING_CHARGES", "No charge entries found for encounter", "ERROR"));

		}

		BigDecimal calculatedTotal = charges.stream() // 1. Open the list of charges

				.map(ChargeEntry::getChargeAmount) // 2. Extract only the 'chargeAmount' from each

				.reduce(BigDecimal.ZERO, BigDecimal::add); // 3. Sum them all up starting from 0.00

		claim.setTotalBilledAmount(calculatedTotal); // 4. Update the Claim object with the truth

		// Rule 2: Check insurance exists for patient

		List<Insurance> insurances = insuranceRepository.findByPatient_PatientIdAndIsDeletedFalse(

				claim.getEncounter().getPatient().getPatientId());

		if (insurances.isEmpty()) {

			edits.add(buildEdit(claim, "MISSING_INSURANCE", "No insurance found for patient", "ERROR"));

		}

		// Rule 3: Check billed amount > 0

		if (claim.getTotalBilledAmount() == null || claim.getTotalBilledAmount().signum() <= 0) {

			edits.add(buildEdit(claim, "INVALID_AMOUNT", "Total billed amount must be greater than 0", "ERROR"));

		}

		// Rule 4: Check each charge has valid ICD+CPT

		for (ChargeEntry charge : charges) {

			if (charge.getIcd() == null || !charge.getIcd().getIsActive()) {

				edits.add(buildEdit(claim, "INVALID_ICD",

						"ICD code is inactive or missing on charge " + charge.getChargeId(), "WARNING"));

			}

			if (charge.getCpt() == null || !charge.getCpt().getIsActive()) {

				edits.add(buildEdit(claim, "INVALID_CPT",

						"CPT code is inactive or missing on charge " + charge.getChargeId(), "WARNING"));

			}

		}

		// Rule 5: Validate ICD-CPT medical necessity

		for (ChargeEntry charge : charges) {

			if (charge.getIcd() != null && charge.getCpt() != null) {

				boolean validMapping =

						icdCptMappingRepository.existsByIcdCodeAndCptCodeAndIsValidTrue(

								charge.getIcd().getIcdCode(),

								charge.getCpt().getCptCode()

						);

				if (!validMapping) {

					edits.add(buildEdit(

							claim,

							"ICD_CPT_MISMATCH",

							"Diagnosis " + charge.getIcd().getIcdCode() +

									" does not justify procedure " + charge.getCpt().getCptCode(),

							"ERROR"

					));

				}

			}

		}

		if (!edits.isEmpty()) {

			claimEditRepository.saveAll(edits);

		}

		return edits;

	}

	private ClaimEdit buildEdit(Claim claim, String type, String message, String severity) {

		ClaimEdit edit = new ClaimEdit();

		edit.setClaim(claim);

		edit.setEditType(type);

		edit.setEditMessage(message);

		edit.setSeverity(severity);

		edit.setCreatedAt(LocalDateTime.now());

		return edit;

	}

}
