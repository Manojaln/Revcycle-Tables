package com.recyclexbackend.controller;

import com.recyclexbackend.dto.request.EncounterRequest;
import com.recyclexbackend.dto.response.ApiResponse;
import com.recyclexbackend.dto.response.EncounterResponse;
import com.recyclexbackend.dto.response.PatientResponse;
import com.recyclexbackend.service.EncounterService;
import com.recyclexbackend.util.SecurityHelper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/encounters")
@PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR', 'MEDICAL_CODER')")
@RequiredArgsConstructor
public class EncounterController {

    private final EncounterService encounterService;
    private final SecurityHelper securityHelper;

    @PostMapping
    public ResponseEntity<ApiResponse<EncounterResponse>> create(@Valid @RequestBody EncounterRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Encounter created",
                encounterService.createEncounter(request, securityHelper.getCurrentUserId())));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<EncounterResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(encounterService.getAllEncounters()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<EncounterResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(encounterService.getById(id)));
    }

    @GetMapping("/patient/{patientId}")
    public ResponseEntity<ApiResponse<List<EncounterResponse>>> getByPatient(@PathVariable Long patientId) {
        return ResponseEntity.ok(ApiResponse.success(encounterService.getByPatient(patientId)));
    }

    @GetMapping("/patients-for-selection")
    public ResponseEntity<ApiResponse<List<PatientResponse>>> getPatientsForSelection() {
        return ResponseEntity.ok(ApiResponse.success("Patients available for encounter registration",
                encounterService.getAvailablePatientsForEncounter()));
    }

//    @GetMapping("/my")
//    public ResponseEntity<ApiResponse<List<EncounterResponse>>> getMine() {
//        return ResponseEntity.ok(ApiResponse.success(
//                encounterService.getByDoctor(securityHelper.getCurrentUserId())));
//    }

}
