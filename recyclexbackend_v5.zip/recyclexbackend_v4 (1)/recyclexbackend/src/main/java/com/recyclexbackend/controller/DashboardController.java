package com.recyclexbackend.controller;

import com.recyclexbackend.dto.response.ApiResponse;
import com.recyclexbackend.dto.response.DashboardResponse;
import com.recyclexbackend.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
@PreAuthorize("hasAnyRole('ADMIN', 'FRONT_DESK', 'MEDICAL_CODER', 'BILLER', 'DENIAL_ANALYST', 'PAYMENT_POSTER')")
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping
    public ResponseEntity<ApiResponse<DashboardResponse>> getDashboard() {
        return ResponseEntity.ok(ApiResponse.success(dashboardService.getDashboard()));
    }
}
