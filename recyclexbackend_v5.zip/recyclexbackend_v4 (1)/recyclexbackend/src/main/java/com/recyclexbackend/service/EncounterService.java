package com.recyclexbackend.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.recyclexbackend.dto.request.EncounterRequest;
import com.recyclexbackend.dto.response.EncounterResponse;
import com.recyclexbackend.dto.response.PatientResponse;
import com.recyclexbackend.entity.Encounter;
import com.recyclexbackend.entity.Patient;
import com.recyclexbackend.entity.User;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.EncounterRepository;
import com.recyclexbackend.repository.PatientRepository;
import com.recyclexbackend.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EncounterService {

    private final EncounterRepository encounterRepository;
    private final PatientRepository patientRepository;
    private final UserRepository userRepository;
    private final AuditLogService auditLogService;
    private final ModelMapper modelMapper;
    
    public EncounterResponse createEncounter(EncounterRequest request, Long doctorId) {
        Patient patient = patientRepository.findByPatientIdAndIsDeletedFalse(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));

        if (patient.getVisitedDoctor()) {
            throw new BadRequestException("Patient has already been diagnosed by a doctor");
        }

        User doctor = userRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));

     /*   Encounter encounter = new Encounter();
        encounter.setPatient(patient);
        encounter.setDoctor(doctor);
        encounter.setServiceDate(request.getServiceDate());
        encounter.setDiagnosisNotes(request.getDiagnosisNotes());
        encounter.setCreatedAt(LocalDateTime.now()); */
        
        Encounter encounter = modelMapper.map(request, Encounter.class);
        encounter.setPatient(patient);
        encounter.setDoctor(doctor);
        encounter.setCreatedAt(LocalDateTime.now());

        Encounter saved = encounterRepository.save(encounter);
        auditLogService.log(doctorId, "ENCOUNTER", saved.getEncounterId(), "CREATE", null, null);

        // Mark patient as visited by doctor
        patient.setVisitedDoctor(true);
        patientRepository.save(patient);

        return toResponse(saved);
    }

    public List<EncounterResponse> getAllEncounters() {
        return encounterRepository.findByIsDeletedFalse().stream()
                .map(this::toResponse).collect(Collectors.toList());
    }

    public EncounterResponse getById(Long id) {
        Encounter enc = encounterRepository.findByEncounterIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("Encounter not found: " + id));
        return toResponse(enc);
    }

    public List<EncounterResponse> getByPatient(Long patientId) {
        return encounterRepository.findByPatient_PatientIdAndIsDeletedFalse(patientId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    /**
     * Fetch all active patients for doctor to select from when registering an encounter.
     * Doctor UI will display this in a table, doctor selects one patient, then adds diagnosis notes.
     */
    public List<PatientResponse> getAvailablePatientsForEncounter() {
        return patientRepository.findByIsDeletedFalseAndVisitedDoctorFalse()
                .stream().map(this::patientToResponse).collect(Collectors.toList());
    }

    public List<EncounterResponse> getUnclaimedChargedEncounters() {
        return encounterRepository.findByChargedTrueAndClaimCreatedFalseAndIsDeletedFalse()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<EncounterResponse> getUnchargedEncounters() {
        return encounterRepository.findByChargedFalseAndIsDeletedFalse()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    private PatientResponse patientToResponse(Patient p) {
        PatientResponse r = new PatientResponse();
        r.setPatientId(p.getPatientId());
        r.setName(p.getName());
        r.setDob(p.getDob());
        r.setGender(p.getGender());
        r.setPhone(p.getPhone());
        r.setEmail(p.getEmail());
        r.setAddress(p.getAddress());
        r.setVisitedDoctor(p.getVisitedDoctor());
        r.setCreatedAt(p.getCreatedAt());
        return r;
    }

//    public List<EncounterResponse> getByDoctor(Long doctorId) {
//        return encounterRepository.findByDoctor_UserIdAndIsDeletedFalse(doctorId)
//                .stream().map(this::toResponse).collect(Collectors.toList());
//    }


    public EncounterResponse toResponse(Encounter e) {
    	
      /*  EncounterResponse r = new EncounterResponse();
        r.setEncounterId(e.getEncounterId());
        r.setPatientId(e.getPatient().getPatientId());
        r.setPatientName(e.getPatient().getName());
        r.setDoctorId(e.getDoctor().getUserId());
        r.setDoctorName(e.getDoctor().getName());
        r.setServiceDate(e.getServiceDate());
        r.setDiagnosisNotes(e.getDiagnosisNotes());
        r.setCreatedAt(e.getCreatedAt());  */
    	
      	EncounterResponse r = modelMapper.map(e, EncounterResponse.class);
      	 r.setPatientId(e.getPatient().getPatientId());
         r.setPatientName(e.getPatient().getName());
         r.setDoctorId(e.getDoctor().getUserId());
         r.setDoctorName(e.getDoctor().getName());
         
        return r;
    }
}
