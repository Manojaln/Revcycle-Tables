package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "claims")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Claim {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long claimId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "encounter_id")
    private Encounter encounter;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payer_id")
    private Payer payer;

    @Column(unique = true)
    private String claimNumber;

    private String status; // DRAFT, SUBMITTED, APPROVED, DENIED, PAID

    private BigDecimal totalBilledAmount;
    private BigDecimal approvedAmount;

    private LocalDateTime submissionDate;
    private LocalDateTime decisionTime;

    private Boolean isDeleted = false;

    private LocalDateTime createdAt = LocalDateTime.now();
}
