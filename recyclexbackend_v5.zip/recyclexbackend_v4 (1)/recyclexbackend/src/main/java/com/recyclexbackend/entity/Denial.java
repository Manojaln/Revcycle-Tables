package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "denials")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Denial {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long denialId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "claim_id")
    private Claim claim;

    private LocalDate denialDate;
    private String reasonCode;
    private String category;
    private String status; // OPEN, REVIEWED, APPEALED, CLOSED

    private LocalDateTime createdAt = LocalDateTime.now();
}
