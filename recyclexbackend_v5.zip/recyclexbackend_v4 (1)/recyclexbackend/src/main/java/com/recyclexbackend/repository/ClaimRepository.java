package com.recyclexbackend.repository;

import com.recyclexbackend.entity.Claim;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ClaimRepository extends JpaRepository<Claim, Long> {
    List<Claim> findByIsDeletedFalse();
    Optional<Claim> findByClaimIdAndIsDeletedFalse(Long id);
    Optional<Claim> findByClaimNumber(String claimNumber);
    List<Claim> findByStatusAndIsDeletedFalse(String status);
    List<Claim> findByEncounter_EncounterIdAndIsDeletedFalse(Long encounterId);

    @Query("SELECT c FROM Claim c WHERE c.status = 'SUBMITTED' AND c.decisionTime <= :now AND c.isDeleted = false")
    List<Claim> findSubmittedClaimsDue(@Param("now") LocalDateTime now);

    @Query("SELECT COUNT(c) FROM Claim c WHERE c.isDeleted = false")
    long countTotal();

    @Query("SELECT COUNT(c) FROM Claim c WHERE c.status = :status AND c.isDeleted = false")
    long countByStatus(@Param("status") String status);
}
