package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "payers")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Payer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long payerId;

    @Column(unique = true)
    private String payerName;

	public Payer(String payerName) {
		super();
		this.payerName = payerName;
	}    
}
