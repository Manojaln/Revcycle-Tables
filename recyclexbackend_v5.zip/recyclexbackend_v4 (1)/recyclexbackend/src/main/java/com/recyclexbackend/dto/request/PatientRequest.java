package com.recyclexbackend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class PatientRequest {

    @NotBlank
    private String name;

    @NotNull
    private LocalDate dob;

    @NotBlank
    private String gender;

    @NotBlank
    private String phone;

    private String email;
    private String address;

    // INSURANCE
    @NotBlank
    private String payerName;

    @NotBlank
    private String policyNumber;

    @NotBlank
    private String coverageDetails;
    @NotNull
    private BigDecimal coverageLimit;
    @NotBlank
    private String eligibilityStatus;
    private Boolean isPrimary = true;

}