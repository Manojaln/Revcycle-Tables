package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.DenialRequest;
import com.recyclexbackend.dto.response.DenialResponse;
import com.recyclexbackend.entity.*;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DenialService {

    private final DenialRepository denialRepository;
    private final ClaimRepository claimRepository;
    private final AuditLogService auditLogService;

    public DenialResponse createDenial(DenialRequest request, Long createdBy) {
        Claim claim = claimRepository.findByClaimIdAndIsDeletedFalse(request.getClaimId())
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found"));

        if (!claim.getStatus().equals("DENIED")) {
            throw new BadRequestException("Denial can only be recorded for DENIED claims");
        }

        Denial denial = new Denial();
        denial.setClaim(claim);
        denial.setDenialDate(request.getDenialDate());
        denial.setReasonCode(request.getReasonCode());
        denial.setCategory(request.getCategory());
        denial.setStatus("OPEN");
        denial.setCreatedAt(LocalDateTime.now());

        Denial saved = denialRepository.save(denial);
        auditLogService.log(createdBy, "DENIAL", saved.getDenialId(), "CREATE",
                null, claim.getClaimNumber());
        return toResponse(saved);
    }

    public List<DenialResponse> getAllDenials() {
        return denialRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<DenialResponse> getDenialsByClaim(Long claimId) {
        return denialRepository.findByClaim_ClaimId(claimId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public DenialResponse updateDenialStatus(Long denialId, String newStatus, Long updatedBy) {
        Denial denial = denialRepository.findById(denialId)
                .orElseThrow(() -> new ResourceNotFoundException("Denial not found"));
        String old = denial.getStatus();
        denial.setStatus(newStatus);
        denialRepository.save(denial);
        auditLogService.log(updatedBy, "DENIAL", denialId, "STATUS_CHANGE", old, newStatus);
        return toResponse(denial);
    }

    public DenialResponse toResponse(Denial d) {
        DenialResponse r = new DenialResponse();
        r.setDenialId(d.getDenialId());
        r.setClaimId(d.getClaim().getClaimId());
        r.setClaimNumber(d.getClaim().getClaimNumber());
        r.setDenialDate(d.getDenialDate());
        r.setReasonCode(d.getReasonCode());
        r.setCategory(d.getCategory());
        r.setStatus(d.getStatus());
        r.setCreatedAt(d.getCreatedAt());
        return r;
    }
}
