package com.recyclexbackend.dto.request;

import java.math.BigDecimal;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceRequest {
    @NotNull
    private Long patientId;

    @NotNull
    private String payerName;

    @NotBlank
    private String policyNumber;

    @NotBlank
    private String coverageDetails;
    @NotNull
    private BigDecimal coverageLimit;
    @NotBlank
    private String eligibilityStatus;
}
