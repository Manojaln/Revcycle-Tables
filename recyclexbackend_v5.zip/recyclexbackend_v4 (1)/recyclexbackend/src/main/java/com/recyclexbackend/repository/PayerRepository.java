package com.recyclexbackend.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.recyclexbackend.entity.Payer;

public interface PayerRepository extends JpaRepository<Payer, Long> {
    Optional<Payer> findByPayerName(String payerName);

    
}
