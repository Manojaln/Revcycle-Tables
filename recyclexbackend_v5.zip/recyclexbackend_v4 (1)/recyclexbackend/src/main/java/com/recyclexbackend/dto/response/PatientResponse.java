package com.recyclexbackend.dto.response;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class PatientResponse {
    private Long patientId;
    private String name;
    private LocalDate dob;
    private String gender;
    private String phone;
    private String email;
    private String address;
    private Boolean visitedDoctor;
    private LocalDateTime createdAt;
}
