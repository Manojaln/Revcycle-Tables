package com.recyclexbackend.repository;

import com.recyclexbackend.entity.Denial;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Map;

public interface DenialRepository extends JpaRepository<Denial, Long> {
    List<Denial> findByClaim_ClaimId(Long claimId);
    List<Denial> findByStatus(String status);

    @Query("SELECT d.reasonCode, COUNT(d) FROM Denial d GROUP BY d.reasonCode")
    List<Object[]> countByReasonCode();

    @Query("SELECT d.category, COUNT(d) FROM Denial d GROUP BY d.category")
    List<Object[]> countByCategory();
}
