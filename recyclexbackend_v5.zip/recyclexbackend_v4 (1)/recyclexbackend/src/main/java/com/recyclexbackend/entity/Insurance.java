package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "insurance")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Insurance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long insuranceId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id")
    private Patient patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payer_id", unique = true)
    private Payer payer;

    @Column(unique = true)
    private String policyNumber;

    private String coverageDetails;
    private BigDecimal coverageLimit;
    private String eligibilityStatus;

    private Boolean isDeleted = false;

    private LocalDateTime createdAt = LocalDateTime.now();
}
