package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "patients",
       uniqueConstraints = @UniqueConstraint(columnNames = {"name", "dob", "phone"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long patientId;

    private String name;
    private LocalDate dob;
    private String gender;
    private String phone;
    private String email;
    private String address;

    private Boolean visitedDoctor = false;

    private Boolean isDeleted = false;

    private Long createdBy;
    private Long updatedBy;

    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt = LocalDateTime.now();
}
