package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.PaymentRequest;
import com.recyclexbackend.dto.response.PaymentResponse;
import com.recyclexbackend.entity.*;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final ClaimRepository claimRepository;
    private final UserRepository userRepository;
    private final AuditLogService auditLogService;

    public PaymentResponse recordPayment(PaymentRequest request, Long postedBy) {
        Claim claim = claimRepository.findByClaimIdAndIsDeletedFalse(request.getClaimId())
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found"));

        if (!claim.getStatus().equals("APPROVED") && !claim.getStatus().equals("PAID")) {
            throw new BadRequestException("Payment can only be recorded for APPROVED or PAID claims");
        }

        User poster = userRepository.findById(postedBy).orElseThrow();

        Payment payment = new Payment();
        payment.setClaim(claim);
        payment.setTransactionReference(request.getTransactionReference());
        payment.setInsurancePayment(request.getInsurancePayment());
        payment.setPatientPayment(request.getPatientPayment());
        payment.setAdjustmentAmount(request.getAdjustmentAmount());
        payment.setSource(request.getSource());
        payment.setDatePosted(request.getDatePosted());
        payment.setCreatedBy(poster);
        payment.setCreatedAt(LocalDateTime.now());

        Payment saved = paymentRepository.save(payment);

        // Update claim to PAID
        claim.setStatus("PAID");
        claimRepository.save(claim);

        auditLogService.log(postedBy, "PAYMENT", saved.getPaymentId(), "CREATE",
                null, "Claim: " + claim.getClaimNumber());

        return toResponse(saved);
    }

    public List<PaymentResponse> getPaymentsByClaim(Long claimId) {
        return paymentRepository.findByClaim_ClaimId(claimId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public PaymentResponse toResponse(Payment p) {
        PaymentResponse r = new PaymentResponse();
        r.setPaymentId(p.getPaymentId());
        r.setClaimId(p.getClaim().getClaimId());
        r.setClaimNumber(p.getClaim().getClaimNumber());
        r.setTransactionReference(p.getTransactionReference());
        r.setInsurancePayment(p.getInsurancePayment());
        r.setPatientPayment(p.getPatientPayment());
        r.setAdjustmentAmount(p.getAdjustmentAmount());
        r.setSource(p.getSource());
        r.setDatePosted(p.getDatePosted());
        r.setPostedBy(p.getCreatedBy() != null ? p.getCreatedBy().getName() : null);
        r.setCreatedAt(p.getCreatedAt());
        return r;
    }
}
