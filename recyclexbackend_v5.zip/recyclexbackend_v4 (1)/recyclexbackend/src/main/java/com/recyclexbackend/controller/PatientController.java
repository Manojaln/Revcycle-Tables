	package com.recyclexbackend.controller;
	
	import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.recyclexbackend.dto.request.PatientInsuranceRequest;
import com.recyclexbackend.dto.response.ApiResponse;
import com.recyclexbackend.dto.response.InsuranceResponse;
import com.recyclexbackend.dto.response.PatientInsuranceResponse;
import com.recyclexbackend.dto.response.PatientResponse;
import com.recyclexbackend.service.InsuranceService;
import com.recyclexbackend.service.PatientService;
import com.recyclexbackend.util.SecurityHelper;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
	
	@RestController
	@RequestMapping("/api/patients")
	@PreAuthorize("hasAnyRole('ADMIN', 'FRONT_DESK')")
	@RequiredArgsConstructor
	public class PatientController {
	
	    private final PatientService patientService;
	    private final InsuranceService insuranceService;
	    private final SecurityHelper securityHelper;
	
	    @PostMapping("/register")
	    public ResponseEntity<ApiResponse<PatientInsuranceResponse>> register(
	            @Valid @RequestBody PatientInsuranceRequest request) {

	        return ResponseEntity.ok(
	                ApiResponse.success(
	                        "Patient, Insurance and Payer registered",
	                        patientService.registerPatientWithInsurance(
	                                request,
	                                securityHelper.getCurrentUserId()
	                        )
	                )
	        );
	    }

	    @PutMapping("/{patientId}")
	    public ResponseEntity<ApiResponse<PatientInsuranceResponse>> updatePatient(
	            @PathVariable Long patientId,
	            @Valid @RequestBody PatientInsuranceRequest request) {

	        return ResponseEntity.ok(
	                ApiResponse.success(
	                        "Patient and Insurance updated",
	                        patientService.updatePatientWithInsurance(
	                                patientId,
	                                request,
	                                securityHelper.getCurrentUserId()
	                        )
	                )
	        );
	    }
	    
	    
	    @GetMapping
	    public ResponseEntity<ApiResponse<List<PatientResponse>>> getAll() {
	        return ResponseEntity.ok(ApiResponse.success(patientService.getAllPatients()));
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<ApiResponse<PatientResponse>> getById(@PathVariable Long id) {
	        return ResponseEntity.ok(ApiResponse.success(patientService.getPatientById(id)));
	    }


	    @DeleteMapping("/{id}")
	    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
	        patientService.deletePatient(id, securityHelper.getCurrentUserId());
	        return ResponseEntity.ok(ApiResponse.success("Patient deleted", null));
	    }	
//	    // Insurance
//	    @PostMapping("/insurance")
//	    public ResponseEntity<ApiResponse<InsuranceResponse>> addInsurance(@Valid @RequestBody InsuranceRequest request) {
//	        return ResponseEntity.ok(ApiResponse.success("Insurance added",
//	                insuranceService.addInsurance(request, securityHelper.getCurrentUserId())));
//	    }
//	
	    @GetMapping("/{patientId}/insurance")
	    public ResponseEntity<ApiResponse<List<InsuranceResponse>>> getInsurance(@PathVariable Long patientId) {
	        return ResponseEntity.ok(ApiResponse.success(insuranceService.getInsuranceByPatient(patientId)));
	    }
	}
