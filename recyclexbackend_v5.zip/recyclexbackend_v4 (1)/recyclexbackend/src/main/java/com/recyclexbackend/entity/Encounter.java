package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "encounters")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Encounter {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long encounterId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id")
    private Patient patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doctor_id")
    private User doctor;

    private LocalDate serviceDate;
    // status field removed as requested
    // assignedCoder field removed as requested

    @Column(columnDefinition = "TEXT")
    private String diagnosisNotes; // IMMUTABLE: Once set during encounter creation, cannot be updated

    private Boolean charged = false; // Flag to track if charges have been entered for this encounter
    private Boolean claimCreated = false; // Flag to track if claim has been created for this encounter

    // version field removed as requested
    private Boolean isDeleted = false;

    private LocalDateTime createdAt = LocalDateTime.now();
}
