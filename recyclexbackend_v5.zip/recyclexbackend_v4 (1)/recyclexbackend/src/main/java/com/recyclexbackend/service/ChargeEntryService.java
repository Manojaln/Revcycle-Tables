package com.recyclexbackend.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.recyclexbackend.dto.request.ChargeEntryRequest;
import com.recyclexbackend.dto.response.ChargeEntryResponse;
import com.recyclexbackend.entity.ChargeEntry;
import com.recyclexbackend.entity.CptMaster;
import com.recyclexbackend.entity.Encounter;
import com.recyclexbackend.entity.IcdMaster;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.ChargeEntryRepository;
import com.recyclexbackend.repository.CptMasterRepository;
import com.recyclexbackend.repository.EncounterRepository;
import com.recyclexbackend.repository.IcdMasterRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ChargeEntryService {

    private final ChargeEntryRepository chargeEntryRepository;
    private final EncounterRepository encounterRepository;
    private final IcdMasterRepository icdMasterRepository;
    private final CptMasterRepository cptMasterRepository;
    private final AuditLogService auditLogService;
    private final ModelMapper modelMapper;

    public ChargeEntryResponse addCharge(ChargeEntryRequest request, Long coderId) {
        Encounter encounter = encounterRepository.findByEncounterIdAndIsDeletedFalse(request.getEncounterId())
                .orElseThrow(() -> new ResourceNotFoundException("Encounter not found"));

        if (encounter.getCharged()) {
            throw new BadRequestException("Charges have already been entered for this encounter");
        }

        IcdMaster icd = icdMasterRepository.findById(request.getIcdCode())
                .orElseThrow(() -> new ResourceNotFoundException("ICD code not found: " + request.getIcdCode()));
        CptMaster cpt = cptMasterRepository.findById(request.getCptCode())
                .orElseThrow(() -> new ResourceNotFoundException("CPT code not found: " + request.getCptCode()));

        BigDecimal chargeAmount = cpt.getDefaultCharge().multiply(BigDecimal.valueOf(request.getUnits()));

     /*   ChargeEntry entry = new ChargeEntry();
        entry.setEncounter(encounter);
        entry.setIcd(icd);
        entry.setCpt(cpt);
        entry.setUnits(request.getUnits());
        entry.setChargeAmount(chargeAmount);
        entry.setCreatedAt(LocalDateTime.now()); */
        
        //Entity->request mapping 
        ChargeEntry entry = modelMapper.map(request, ChargeEntry.class);
        entry.setEncounter(encounter);
        entry.setIcd(icd);
        entry.setCpt(cpt);
        entry.setChargeAmount(chargeAmount);
        entry.setCreatedAt(LocalDateTime.now());

        ChargeEntry saved = chargeEntryRepository.save(entry);

        // Mark encounter as charged
        encounter.setCharged(true);
        encounterRepository.save(encounter);

        auditLogService.log(coderId, "CHARGE_ENTRY", saved.getChargeId(), "CREATE",
                null, cpt.getCptCode() + " x" + request.getUnits());
        return toResponse(saved);
    }

    public List<ChargeEntryResponse> getChargesByEncounter(Long encounterId) {
        return chargeEntryRepository.findByEncounter_EncounterId(encounterId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public void deleteCharge(Long chargeId, Long deletedBy) {
        ChargeEntry entry = chargeEntryRepository.findById(chargeId)
                .orElseThrow(() -> new ResourceNotFoundException("Charge not found: " + chargeId));
        chargeEntryRepository.delete(entry);
        auditLogService.log(deletedBy, "CHARGE_ENTRY", chargeId, "DELETE", entry.getCpt().getCptCode(), null);
    }

    public ChargeEntryResponse toResponse(ChargeEntry c) {
    	
   /*     ChargeEntryResponse r = new ChargeEntryResponse();
        r.setChargeId(c.getChargeId());
        r.setEncounterId(c.getEncounter().getEncounterId());
        r.setIcdCode(c.getIcd().getIcdCode());
        r.setIcdDescription(c.getIcd().getDescription());
        r.setCptCode(c.getCpt().getCptCode());
        r.setCptDescription(c.getCpt().getDescription());
        r.setUnits(c.getUnits());
        r.setChargeAmount(c.getChargeAmount());
        r.setCreatedAt(c.getCreatedAt()); */
    	
      	//entity->response mapping 
    	    ChargeEntryResponse r = modelMapper.map(c, ChargeEntryResponse.class);
    	    r.setEncounterId(c.getEncounter().getEncounterId());
        r.setIcdCode(c.getIcd().getIcdCode());
        r.setIcdDescription(c.getIcd().getDescription());
        r.setCptCode(c.getCpt().getCptCode());
        r.setCptDescription(c.getCpt().getDescription());
        return r;
    }
}
