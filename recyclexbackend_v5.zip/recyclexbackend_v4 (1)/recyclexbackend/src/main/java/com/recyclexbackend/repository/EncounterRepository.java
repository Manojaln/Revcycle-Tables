package com.recyclexbackend.repository;

import com.recyclexbackend.entity.Encounter;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface EncounterRepository extends JpaRepository<Encounter, Long> {
    List<Encounter> findByIsDeletedFalse();
    List<Encounter> findByChargedTrueAndClaimCreatedFalseAndIsDeletedFalse();
    List<Encounter> findByChargedFalseAndIsDeletedFalse();
    Optional<Encounter> findByEncounterIdAndIsDeletedFalse(Long id);
    List<Encounter> findByPatient_PatientIdAndIsDeletedFalse(Long patientId);
    List<Encounter> findByDoctor_UserIdAndIsDeletedFalse(Long doctorId);
    // assignedCoder and status filters removed from Encounter
}
