package com.recyclexbackend.repository;

import com.recyclexbackend.entity.Insurance;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface InsuranceRepository extends JpaRepository<Insurance, Long> {

    List<Insurance> findByPatient_PatientIdAndIsDeletedFalse(Long patientId);

    Optional<Insurance> findByPolicyNumber(String policyNumber);

    Optional<Insurance> findFirstByPatient_PatientIdAndIsDeletedFalse(Long patientId);
    
    boolean  existsByPatientPatientId(Long patientId);

}