package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.PayerRequest;
import com.recyclexbackend.entity.Payer;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.PayerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PayerService {

    private final PayerRepository payerRepository;

    public Payer createPayer(PayerRequest request) {
        Payer payer = new Payer();
        payer.setPayerName(request.getPayerName());
        payer.setIsActive(true);
        payer.setCreatedAt(LocalDateTime.now());
        return payerRepository.save(payer);
    }

    public List<Payer> getAllPayers() {
        return payerRepository.findByIsActiveTrue();
    }

    public Payer getById(Long id) {
        return payerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payer not found: " + id));
    }
}
