package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.InsuranceRequest;
import com.recyclexbackend.dto.response.InsuranceResponse;
import com.recyclexbackend.entity.Insurance;
import com.recyclexbackend.entity.Patient;
import com.recyclexbackend.entity.Payer;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.InsuranceRepository;
import com.recyclexbackend.repository.PatientRepository;
import com.recyclexbackend.repository.PayerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InsuranceService {

    private final InsuranceRepository insuranceRepository;
    private final PatientRepository patientRepository;
    private final PayerRepository payerRepository;
    private final AuditLogService auditLogService;

    public InsuranceResponse addInsurance(InsuranceRequest request, Long createdBy) {
        Patient patient = patientRepository.findByPatientIdAndIsDeletedFalse(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));
        Payer payer = payerRepository.findById(request.getPayerId())
                .orElseThrow(() -> new ResourceNotFoundException("Payer not found"));

        if (insuranceRepository.findByPolicyNumber(request.getPolicyNumber()).isPresent()) {
            throw new BadRequestException("Policy number already exists: " + request.getPolicyNumber());
        }

        Insurance insurance = new Insurance();
        insurance.setPatient(patient);
        insurance.setPayer(payer);
        insurance.setPolicyNumber(request.getPolicyNumber());
        insurance.setCoverageDetails(request.getCoverageDetails());
        insurance.setCoverageLimit(request.getCoverageLimit());
        insurance.setEligibilityStatus(request.getEligibilityStatus());
        insurance.setVerifiedDate(request.getVerifiedDate());
        insurance.setIsPrimary(request.getIsPrimary());
        insurance.setCreatedAt(LocalDateTime.now());

        Insurance saved = insuranceRepository.save(insurance);
        auditLogService.log(createdBy, "INSURANCE", saved.getInsuranceId(), "CREATE", null, saved.getPolicyNumber());
        return toResponse(saved);
    }

    public List<InsuranceResponse> getInsuranceByPatient(Long patientId) {
        return insuranceRepository.findByPatient_PatientIdAndIsDeletedFalse(patientId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public InsuranceResponse getById(Long id) {
        Insurance insurance = insuranceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Insurance not found: " + id));
        return toResponse(insurance);
    }

    public InsuranceResponse toResponse(Insurance i) {
        InsuranceResponse r = new InsuranceResponse();
        r.setInsuranceId(i.getInsuranceId());
        r.setPatientId(i.getPatient().getPatientId());
        r.setPatientName(i.getPatient().getName());
        r.setPayerId(i.getPayer().getPayerId());
        r.setPayerName(i.getPayer().getPayerName());
        r.setPolicyNumber(i.getPolicyNumber());
        r.setCoverageDetails(i.getCoverageDetails());
        r.setCoverageLimit(i.getCoverageLimit());
        r.setEligibilityStatus(i.getEligibilityStatus());
        r.setVerifiedDate(i.getVerifiedDate());
        r.setIsPrimary(i.getIsPrimary());
        r.setCreatedAt(i.getCreatedAt());
        return r;
    }
}
