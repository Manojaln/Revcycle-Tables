package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.PatientRequest;
import com.recyclexbackend.dto.response.PatientResponse;
import com.recyclexbackend.entity.Patient;
import com.recyclexbackend.entity.User;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.PatientRepository;
import com.recyclexbackend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PatientService {

    private final PatientRepository patientRepository;
    private final UserRepository userRepository;
    private final AuditLogService auditLogService;

    public PatientResponse registerPatient(PatientRequest request, Long createdBy) {
        if (patientRepository.existsByNameAndDobAndPhone(request.getName(), request.getDob(), request.getPhone())) {
            throw new BadRequestException("Patient with same name, dob, and phone already exists.");
        }

        User frontdesk = userRepository.findById(createdBy).orElseThrow();

        Patient patient = new Patient();
        patient.setName(request.getName());
        patient.setDob(request.getDob());
        patient.setGender(request.getGender());
        patient.setPhone(request.getPhone());
        patient.setEmail(request.getEmail());
        patient.setAddress(request.getAddress());
        patient.setAssignedFrontdesk(frontdesk);
        patient.setCreatedBy(createdBy);
        patient.setUpdatedBy(createdBy);
        patient.setCreatedAt(LocalDateTime.now());
        patient.setUpdatedAt(LocalDateTime.now());

        Patient saved = patientRepository.save(patient);
        auditLogService.log(createdBy, "PATIENT", saved.getPatientId(), "CREATE", null, saved.getName());
        return toResponse(saved);
    }

    public List<PatientResponse> getAllPatients() {
        return patientRepository.findByIsDeletedFalse().stream()
                .map(this::toResponse).collect(Collectors.toList());
    }

    public PatientResponse getPatientById(Long id) {
        Patient patient = patientRepository.findByPatientIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found: " + id));
        return toResponse(patient);
    }

    public PatientResponse updatePatient(Long id, PatientRequest request, Long updatedBy) {
        Patient patient = patientRepository.findByPatientIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found: " + id));

        String old = patient.getName();
        patient.setName(request.getName());
        patient.setDob(request.getDob());
        patient.setGender(request.getGender());
        patient.setPhone(request.getPhone());
        patient.setEmail(request.getEmail());
        patient.setAddress(request.getAddress());
        patient.setUpdatedBy(updatedBy);
        patient.setUpdatedAt(LocalDateTime.now());
        patient.setVersion(patient.getVersion() + 1);

        Patient saved = patientRepository.save(patient);
        auditLogService.log(updatedBy, "PATIENT", id, "UPDATE", old, saved.getName());
        return toResponse(saved);
    }

    public void deletePatient(Long id, Long deletedBy) {
        Patient patient = patientRepository.findByPatientIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found: " + id));
        patient.setIsDeleted(true);
        patient.setUpdatedBy(deletedBy);
        patientRepository.save(patient);
        auditLogService.log(deletedBy, "PATIENT", id, "DELETE", patient.getName(), null);
    }

    public PatientResponse toResponse(Patient p) {
        PatientResponse r = new PatientResponse();
        r.setPatientId(p.getPatientId());
        r.setName(p.getName());
        r.setDob(p.getDob());
        r.setGender(p.getGender());
        r.setPhone(p.getPhone());
        r.setEmail(p.getEmail());
        r.setAddress(p.getAddress());
        r.setCreatedAt(p.getCreatedAt());
        if (p.getAssignedFrontdesk() != null) {
            r.setAssignedFrontdeskId(p.getAssignedFrontdesk().getUserId());
            r.setAssignedFrontdeskName(p.getAssignedFrontdesk().getName());
        }
        return r;
    }
}
