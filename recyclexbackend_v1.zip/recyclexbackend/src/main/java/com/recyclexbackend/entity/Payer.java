package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "payers")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Payer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long payerId;

    @Column(unique = true)
    private String payerName;

    private Boolean isActive = true;

    private LocalDateTime createdAt = LocalDateTime.now();

	public Payer(String payerName, Boolean isActive) {
		super();
		this.payerName = payerName;
		this.isActive = isActive;
	}
    
    
}
