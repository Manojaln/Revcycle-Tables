package com.recyclexbackend.repository;

import com.recyclexbackend.entity.Payer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PayerRepository extends JpaRepository<Payer, Long> {
    List<Payer> findByIsActiveTrue();
}
