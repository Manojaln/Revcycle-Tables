package com.recyclexbackend.config;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.recyclexbackend.entity.CptMaster;
import com.recyclexbackend.entity.IcdCptMapping;
import com.recyclexbackend.entity.IcdMaster;
import com.recyclexbackend.entity.Payer;
import com.recyclexbackend.entity.Role;
import com.recyclexbackend.entity.SystemConfig;
import com.recyclexbackend.entity.User;
import com.recyclexbackend.repository.CptMasterRepository;
import com.recyclexbackend.repository.IcdCptMappingRepository;
import com.recyclexbackend.repository.IcdMasterRepository;
import com.recyclexbackend.repository.PayerRepository;
import com.recyclexbackend.repository.RoleRepository;
import com.recyclexbackend.repository.SystemConfigRepository;
import com.recyclexbackend.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    private final IcdMasterRepository icdMasterRepository;
    private final CptMasterRepository cptMasterRepository;
    private final SystemConfigRepository systemConfigRepository;
    private final IcdCptMappingRepository icdCptMappingRepository;
    private final PayerRepository payerRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        seedRoles();
        seedAdminUser();
        seedDoctorUser();
        seedMedicalCoderUser();
        seedIcdCodes();
        seedCptCodes();
        seedIcdCptMappings();
        seedSystemConfig();
        seedPayers();
        log.info("Data initialization complete.");
    }

    private void seedRoles() {
        if (roleRepository.count() == 0) {
            roleRepository.save(new Role(1L, "ADMIN", LocalDateTime.now()));
            roleRepository.save(new Role(2L, "FRONT_DESK", LocalDateTime.now()));
            roleRepository.save(new Role(3L, "DOCTOR", LocalDateTime.now()));
            roleRepository.save(new Role(4L, "MEDICAL_CODER", LocalDateTime.now()));
            roleRepository.save(new Role(5L, "BILLER", LocalDateTime.now()));
            roleRepository.save(new Role(6L, "PAYMENT_POSTER", LocalDateTime.now()));
            roleRepository.save(new Role(7L, "DENIAL_ANALYST", LocalDateTime.now()));
            log.info("Roles seeded.");
        }
    }

    private void seedAdminUser() {
        if (!userRepository.existsByEmail("admin@recyclexbackend.com")) {
            Role adminRole = roleRepository.findByRoleName("ADMIN").orElseThrow();
            User admin = new User();
            admin.setName("System Admin");
            admin.setEmail("admin@recyclexbackend.com");
            admin.setPassword(passwordEncoder.encode("Admin@123"));
            admin.setRole(adminRole);
            admin.setIsActive(true);
            admin.setCreatedAt(LocalDateTime.now());
            admin.setUpdatedAt(LocalDateTime.now());
            userRepository.save(admin);
            log.info("Admin user seeded: admin@recyclexbackend.com / Admin@123");
        }
    }
    
    private void seedDoctorUser() {
    	 
        if (!userRepository.existsByEmail("doctor@recyclexbackend.com")) {
     
            Role doctorRole = roleRepository.findByRoleName("DOCTOR").orElseThrow();
     
            User doctor = new User();
            doctor.setName("Dr. John Smith");
            doctor.setEmail("doctor@recyclexbackend.com");
            doctor.setPassword(passwordEncoder.encode("Doctor@123"));
            doctor.setRole(doctorRole);
            doctor.setIsActive(true);
            doctor.setCreatedAt(LocalDateTime.now());
            doctor.setUpdatedAt(LocalDateTime.now());
     
            userRepository.save(doctor);
     
            log.info("Doctor user seeded: doctor@recyclexbackend.com / Doctor@123");
        }
    }
    
    private void seedMedicalCoderUser() {
    	 
        if (!userRepository.existsByEmail("coder@recyclexbackend.com")) {
     
            Role coderRole = roleRepository.findByRoleName("MEDICAL_CODER").orElseThrow();
     
            User coder = new User();
            coder.setName("Medical Coder");
            coder.setEmail("coder@recyclexbackend.com");
            coder.setPassword(passwordEncoder.encode("Coder@123"));
            coder.setRole(coderRole);
            coder.setIsActive(true);
            coder.setCreatedAt(LocalDateTime.now());
            coder.setUpdatedAt(LocalDateTime.now());
     
            userRepository.save(coder);
     
            log.info("Coder user seeded: coder@recyclexbackend.com / Coder@123");
        }
    }
    
    private void seedPayers() {
   	 
        if(payerRepository.count() == 0) {
     
            payerRepository.save(new Payer("Blue Cross Blue Shield", true));
            payerRepository.save(new Payer("Medicare", true));
            payerRepository.save(new Payer("Aetna", true));
            payerRepository.save(new Payer("United Healthcare", true));
            payerRepository.save(new Payer("Cigna", true));
            payerRepository.save(new Payer("Humana", true));
            payerRepository.save(new Payer("Kaiser Permanente", true));
            payerRepository.save(new Payer("Anthem", true));
            payerRepository.save(new Payer("Medicaid", true));
            payerRepository.save(new Payer("Centene", true));
     
        }
    }

    private void seedIcdCodes() {
        if (icdMasterRepository.count() == 0) {
        	icdMasterRepository.save(new IcdMaster("J06.9","Acute upper respiratory infection",true));
        	icdMasterRepository.save(new IcdMaster("I10","Essential hypertension",true));
        	icdMasterRepository.save(new IcdMaster("E11.9","Type 2 diabetes mellitus",true));
        	icdMasterRepository.save(new IcdMaster("Z00.00","General adult medical examination",true));
        	icdMasterRepository.save(new IcdMaster("M54.5","Low back pain",true));
        	icdMasterRepository.save(new IcdMaster("K21.9","GERD without esophagitis",true));
        	icdMasterRepository.save(new IcdMaster("F32.9","Major depressive disorder",true));
        	icdMasterRepository.save(new IcdMaster("J45.909","Asthma unspecified",true));
        	icdMasterRepository.save(new IcdMaster("J18.9","Pneumonia unspecified",true));
        	icdMasterRepository.save(new IcdMaster("R07.9","Chest pain unspecified",true));
        	icdMasterRepository.save(new IcdMaster("R51","Headache",true));
        	icdMasterRepository.save(new IcdMaster("K52.9","Gastroenteritis",true));
        	icdMasterRepository.save(new IcdMaster("J30.9","Allergic rhinitis",true));
        	icdMasterRepository.save(new IcdMaster("L03.90","Cellulitis unspecified",true));
        	icdMasterRepository.save(new IcdMaster("N39.0","Urinary tract infection",true));
        	icdMasterRepository.save(new IcdMaster("E78.5","Hyperlipidemia",true));
        	icdMasterRepository.save(new IcdMaster("M25.561","Right knee pain",true));
        	icdMasterRepository.save(new IcdMaster("M25.562","Left knee pain",true));
        	icdMasterRepository.save(new IcdMaster("R42","Dizziness",true));
        	icdMasterRepository.save(new IcdMaster("H10.9","Conjunctivitis",true));
        	icdMasterRepository.save(new IcdMaster("H66.90","Otitis media",true));
        	icdMasterRepository.save(new IcdMaster("R05","Cough",true));
        	icdMasterRepository.save(new IcdMaster("R11.2","Nausea with vomiting",true));
        	icdMasterRepository.save(new IcdMaster("E03.9","Hypothyroidism",true));
        	icdMasterRepository.save(new IcdMaster("E66.9","Obesity",true));
        	icdMasterRepository.save(new IcdMaster("G43.909","Migraine",true));
        	icdMasterRepository.save(new IcdMaster("I25.10","Coronary artery disease",true));
        	icdMasterRepository.save(new IcdMaster("I50.9","Heart failure",true));
        	icdMasterRepository.save(new IcdMaster("K35.80","Appendicitis",true));
        	icdMasterRepository.save(new IcdMaster("N20.0","Kidney stone",true));
        	icdMasterRepository.save(new IcdMaster("R10.9","Abdominal pain",true));
        	icdMasterRepository.save(new IcdMaster("R06.02","Shortness of breath",true));
        	icdMasterRepository.save(new IcdMaster("J20.9","Acute bronchitis",true));
        	icdMasterRepository.save(new IcdMaster("J32.9","Chronic sinusitis",true));
        	icdMasterRepository.save(new IcdMaster("H52.4","Presbyopia",true));
        	icdMasterRepository.save(new IcdMaster("H25.9","Cataract",true));
        	icdMasterRepository.save(new IcdMaster("D64.9","Anemia",true));
        	icdMasterRepository.save(new IcdMaster("G47.00","Insomnia",true));
        	icdMasterRepository.save(new IcdMaster("M81.0","Osteoporosis",true));
        	icdMasterRepository.save(new IcdMaster("L70.0","Acne",true));
        	icdMasterRepository.save(new IcdMaster("K64.9","Hemorrhoids",true));
        	icdMasterRepository.save(new IcdMaster("J02.9","Pharyngitis",true));
        	icdMasterRepository.save(new IcdMaster("B34.9","Viral infection",true));
        	icdMasterRepository.save(new IcdMaster("Z23","Immunization encounter",true));
        	icdMasterRepository.save(new IcdMaster("R53.83","Fatigue",true));
        	icdMasterRepository.save(new IcdMaster("M25.511","Shoulder pain",true));
        	icdMasterRepository.save(new IcdMaster("M25.521","Elbow pain",true));
        	icdMasterRepository.save(new IcdMaster("M25.531","Wrist pain",true));
        	icdMasterRepository.save(new IcdMaster("M25.571","Ankle pain",true));
        	icdMasterRepository.save(new IcdMaster("R50.9","Fever",true));
        	icdMasterRepository.save(new IcdMaster("H81.10","Vertigo",true));
        	icdMasterRepository.save(new IcdMaster("L98.9","Skin disorder",true));
        	icdMasterRepository.save(new IcdMaster("R63.5","Weight gain",true));
        	icdMasterRepository.save(new IcdMaster("I63.9","Stroke",true));
        	icdMasterRepository.save(new IcdMaster("G40.909","Epilepsy",true));
        	icdMasterRepository.save(new IcdMaster("J44.9","COPD",true));
        	icdMasterRepository.save(new IcdMaster("M10.9","Gout",true));
        	icdMasterRepository.save(new IcdMaster("N40.0","BPH",true));
        	icdMasterRepository.save(new IcdMaster("R39.15","Urinary urgency",true));
        	icdMasterRepository.save(new IcdMaster("K29.70","Gastritis",true));
        	icdMasterRepository.save(new IcdMaster("K59.00","Constipation",true));
        	icdMasterRepository.save(new IcdMaster("H57.10","Eye pain",true));
        	icdMasterRepository.save(new IcdMaster("R41.3","Memory loss",true));
        	icdMasterRepository.save(new IcdMaster("I48.91","Atrial fibrillation",true));
        	icdMasterRepository.save(new IcdMaster("J04.0","Laryngitis",true));
        	icdMasterRepository.save(new IcdMaster("H61.23","Ear wax impaction",true));
        	icdMasterRepository.save(new IcdMaster("R09.81","Nasal congestion",true));
        	icdMasterRepository.save(new IcdMaster("R25.2","Muscle cramps",true));
        	icdMasterRepository.save(new IcdMaster("R60.0","Edema",true));
        	icdMasterRepository.save(new IcdMaster("M17.9","Knee osteoarthritis",true));
        	icdMasterRepository.save(new IcdMaster("M16.9","Hip osteoarthritis",true));
        	icdMasterRepository.save(new IcdMaster("H04.123","Dry eye syndrome",true));
        	icdMasterRepository.save(new IcdMaster("R20.2","Tingling sensation",true));
        	icdMasterRepository.save(new IcdMaster("L50.9","Urticaria",true));
        	icdMasterRepository.save(new IcdMaster("M62.81","Muscle weakness",true));
        	icdMasterRepository.save(new IcdMaster("R53.1","Weakness",true));
        	icdMasterRepository.save(new IcdMaster("K76.0","Fatty liver",true));
        	icdMasterRepository.save(new IcdMaster("E55.9","Vitamin D deficiency",true));
        	icdMasterRepository.save(new IcdMaster("D50.9","Iron deficiency anemia",true));
        	icdMasterRepository.save(new IcdMaster("R07.81","Chest wall pain",true));
        	icdMasterRepository.save(new IcdMaster("R35.0","Frequent urination",true));
        	icdMasterRepository.save(new IcdMaster("M25.551","Hip pain",true));
        	icdMasterRepository.save(new IcdMaster("J01.90","Acute sinusitis",true));
        	icdMasterRepository.save(new IcdMaster("R73.9","Abnormal glucose",true));
        	icdMasterRepository.save(new IcdMaster("Z13.1","Diabetes screening",true));
        	icdMasterRepository.save(new IcdMaster("Z12.11","Colon cancer screening",true));
        	icdMasterRepository.save(new IcdMaster("Z12.31","Breast cancer screening",true));
        	icdMasterRepository.save(new IcdMaster("Z01.818","Preoperative exam",true));
        	icdMasterRepository.save(new IcdMaster("Z79.4","Long term insulin use",true));
        	icdMasterRepository.save(new IcdMaster("Z79.899","Long term drug therapy",true));
        	icdMasterRepository.save(new IcdMaster("Z68.30","BMI 30-30.9",true));
        	icdMasterRepository.save(new IcdMaster("Z68.31","BMI 31-31.9",true));
        	icdMasterRepository.save(new IcdMaster("Z68.32","BMI 32-32.9",true));
        	icdMasterRepository.save(new IcdMaster("Z68.33","BMI 33-33.9",true));
        	icdMasterRepository.save(new IcdMaster("Z68.34","BMI 34-34.9",true));
        	icdMasterRepository.save(new IcdMaster("Z68.35","BMI 35-35.9",true));
        	icdMasterRepository.save(new IcdMaster("Z68.36","BMI 36-36.9",true));
        	icdMasterRepository.save(new IcdMaster("Z68.37","BMI 37-37.9",true));
        	icdMasterRepository.save(new IcdMaster("Z68.38","BMI 38-38.9",true));
        	icdMasterRepository.save(new IcdMaster("Z68.39","BMI 39-39.9",true));
        	icdMasterRepository.save(new IcdMaster("Z68.40","BMI 40+",true));
            log.info("ICD codes seeded.");
        }
    }

    private void seedCptCodes() {
        if (cptMasterRepository.count() == 0) {
        	cptMasterRepository.save(new CptMaster("99211","Office visit minimal", new BigDecimal("40.00"),true));
        	cptMasterRepository.save(new CptMaster("99212","Office visit established level 2", new BigDecimal("70.00"),true));
        	cptMasterRepository.save(new CptMaster("99213","Office visit established level 3", new BigDecimal("95.00"),true));
        	cptMasterRepository.save(new CptMaster("99214","Office visit established level 4", new BigDecimal("135.00"),true));
        	cptMasterRepository.save(new CptMaster("99215","Office visit established level 5", new BigDecimal("190.00"),true));
        	cptMasterRepository.save(new CptMaster("99202","Office visit new patient level 2", new BigDecimal("85.00"),true));
        	cptMasterRepository.save(new CptMaster("99203","Office visit new patient level 3", new BigDecimal("110.00"),true));
        	cptMasterRepository.save(new CptMaster("99204","Office visit new patient level 4", new BigDecimal("165.00"),true));
        	cptMasterRepository.save(new CptMaster("99205","Office visit new patient level 5", new BigDecimal("220.00"),true));
        	cptMasterRepository.save(new CptMaster("71045","Chest X-ray single view", new BigDecimal("90.00"),true));
        	cptMasterRepository.save(new CptMaster("71046","Chest X-ray two views", new BigDecimal("120.00"),true));
        	cptMasterRepository.save(new CptMaster("70450","CT head without contrast", new BigDecimal("350.00"),true));
        	cptMasterRepository.save(new CptMaster("70460","CT head with contrast", new BigDecimal("420.00"),true));
        	cptMasterRepository.save(new CptMaster("74176","CT abdomen without contrast", new BigDecimal("450.00"),true));
        	cptMasterRepository.save(new CptMaster("74177","CT abdomen with contrast", new BigDecimal("520.00"),true));
        	cptMasterRepository.save(new CptMaster("73562","X-ray knee", new BigDecimal("130.00"),true));
        	cptMasterRepository.save(new CptMaster("72100","Lumbar spine X-ray", new BigDecimal("140.00"),true));
        	cptMasterRepository.save(new CptMaster("80053","Comprehensive metabolic panel", new BigDecimal("55.00"),true));
        	cptMasterRepository.save(new CptMaster("80061","Lipid panel", new BigDecimal("60.00"),true));
        	cptMasterRepository.save(new CptMaster("83036","Hemoglobin A1C", new BigDecimal("50.00"),true));
        	cptMasterRepository.save(new CptMaster("85025","Complete blood count", new BigDecimal("40.00"),true));
        	cptMasterRepository.save(new CptMaster("81003","Urinalysis automated", new BigDecimal("25.00"),true));
        	cptMasterRepository.save(new CptMaster("87086","Urine culture", new BigDecimal("65.00"),true));
        	cptMasterRepository.save(new CptMaster("20610","Joint injection major joint", new BigDecimal("95.00"),true));
        	cptMasterRepository.save(new CptMaster("20550","Tendon sheath injection", new BigDecimal("80.00"),true));
        	cptMasterRepository.save(new CptMaster("36415","Blood collection venipuncture", new BigDecimal("15.00"),true));
        	cptMasterRepository.save(new CptMaster("96372","Therapeutic injection", new BigDecimal("60.00"),true));
        	cptMasterRepository.save(new CptMaster("96365","IV infusion initial hour", new BigDecimal("150.00"),true));
        	cptMasterRepository.save(new CptMaster("97110","Therapeutic exercises", new BigDecimal("75.00"),true));
        	cptMasterRepository.save(new CptMaster("97140","Manual therapy", new BigDecimal("80.00"),true));
        	cptMasterRepository.save(new CptMaster("97530","Therapeutic activities", new BigDecimal("85.00"),true));
        	cptMasterRepository.save(new CptMaster("97010","Hot or cold packs therapy", new BigDecimal("20.00"),true));
        	cptMasterRepository.save(new CptMaster("97032","Electrical stimulation therapy", new BigDecimal("30.00"),true));
        	cptMasterRepository.save(new CptMaster("90471","Immunization administration", new BigDecimal("25.00"),true));
        	cptMasterRepository.save(new CptMaster("90472","Additional immunization", new BigDecimal("18.00"),true));
        	cptMasterRepository.save(new CptMaster("90658","Influenza vaccine", new BigDecimal("45.00"),true));
        	cptMasterRepository.save(new CptMaster("90715","Tdap vaccine", new BigDecimal("60.00"),true));
        	cptMasterRepository.save(new CptMaster("90732","Pneumococcal vaccine", new BigDecimal("75.00"),true));
        	
            log.info("CPT codes seeded.");
        }
    }
    
    private void seedIcdCptMappings() {
    	 
        if(icdCptMappingRepository.count() == 0) {
     
        	icdCptMappingRepository.save(new IcdCptMapping("E11.9","83036",true));
        	icdCptMappingRepository.save(new IcdCptMapping("J18.9","71046",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R07.9","93000",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M54.5","72100",true));
        	icdCptMappingRepository.save(new IcdCptMapping("N39.0","81003",true));
        	icdCptMappingRepository.save(new IcdCptMapping("J02.9","87880",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R05","71046",true));
        	icdCptMappingRepository.save(new IcdCptMapping("E78.5","80061",true));
        	icdCptMappingRepository.save(new IcdCptMapping("I10","80061",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M25.561","73562",true));
        	 
        	icdCptMappingRepository.save(new IcdCptMapping("M25.562","73562",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R10.9","74176",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R51","70450",true));
        	icdCptMappingRepository.save(new IcdCptMapping("K21.9","43235",true));
        	icdCptMappingRepository.save(new IcdCptMapping("L03.90","10060",true));
        	icdCptMappingRepository.save(new IcdCptMapping("F41.9","99214",true));
        	icdCptMappingRepository.save(new IcdCptMapping("F32.9","99214",true));
        	icdCptMappingRepository.save(new IcdCptMapping("J45.909","94010",true));
        	icdCptMappingRepository.save(new IcdCptMapping("S93.401A","73610",true));
        	icdCptMappingRepository.save(new IcdCptMapping("S52.501A","73090",true));
        	 
        	icdCptMappingRepository.save(new IcdCptMapping("K35.80","44970",true));
        	icdCptMappingRepository.save(new IcdCptMapping("N20.0","74176",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R42","93000",true));
        	icdCptMappingRepository.save(new IcdCptMapping("H10.9","99213",true));
        	icdCptMappingRepository.save(new IcdCptMapping("H66.90","92557",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M79.1","97110",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R11.2","80053",true));
        	icdCptMappingRepository.save(new IcdCptMapping("E03.9","84443",true));
        	icdCptMappingRepository.save(new IcdCptMapping("E66.9","97802",true));
        	icdCptMappingRepository.save(new IcdCptMapping("G43.909","99214",true));
        	 
        	icdCptMappingRepository.save(new IcdCptMapping("I25.10","93000",true));
        	icdCptMappingRepository.save(new IcdCptMapping("I50.9","93306",true));
        	icdCptMappingRepository.save(new IcdCptMapping("K52.9","80053",true));
        	icdCptMappingRepository.save(new IcdCptMapping("J30.9","95004",true));
        	icdCptMappingRepository.save(new IcdCptMapping("L20.9","99213",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R73.9","82947",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R06.02","94010",true));
        	icdCptMappingRepository.save(new IcdCptMapping("N18.9","80069",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M54.2","72040",true));
        	icdCptMappingRepository.save(new IcdCptMapping("H52.4","92014",true));
        	 
        	icdCptMappingRepository.save(new IcdCptMapping("H25.9","66984",true));
        	icdCptMappingRepository.save(new IcdCptMapping("K80.20","74177",true));
        	icdCptMappingRepository.save(new IcdCptMapping("D64.9","85025",true));
        	icdCptMappingRepository.save(new IcdCptMapping("G47.00","95810",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M81.0","77080",true));
        	icdCptMappingRepository.save(new IcdCptMapping("L70.0","99213",true));
        	icdCptMappingRepository.save(new IcdCptMapping("K64.9","46600",true));
        	icdCptMappingRepository.save(new IcdCptMapping("B34.9","99213",true));
        	icdCptMappingRepository.save(new IcdCptMapping("Z23","90471",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R53.83","80053",true));
        	 
        	icdCptMappingRepository.save(new IcdCptMapping("J20.9","71046",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M25.511","73030",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M25.521","73080",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M25.531","73110",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M25.571","73610",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R50.9","85025",true));
        	icdCptMappingRepository.save(new IcdCptMapping("H81.10","92540",true));
        	icdCptMappingRepository.save(new IcdCptMapping("L98.9","11102",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R63.5","84443",true));
        	icdCptMappingRepository.save(new IcdCptMapping("I63.9","70551",true));
        	 
        	icdCptMappingRepository.save(new IcdCptMapping("G40.909","95816",true));
        	icdCptMappingRepository.save(new IcdCptMapping("J44.9","94010",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M10.9","84550",true));
        	icdCptMappingRepository.save(new IcdCptMapping("L03.116","10060",true));
        	icdCptMappingRepository.save(new IcdCptMapping("N40.0","51798",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R39.15","51702",true));
        	icdCptMappingRepository.save(new IcdCptMapping("K29.70","43235",true));
        	icdCptMappingRepository.save(new IcdCptMapping("K59.00","74018",true));
        	icdCptMappingRepository.save(new IcdCptMapping("H57.10","92014",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R41.3","96116",true));
        	 
        	icdCptMappingRepository.save(new IcdCptMapping("I48.91","93000",true));
        	icdCptMappingRepository.save(new IcdCptMapping("J04.0","31575",true));
        	icdCptMappingRepository.save(new IcdCptMapping("H61.23","69210",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R09.81","31231",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R25.2","97110",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R60.0","93970",true));
        	icdCptMappingRepository.save(new IcdCptMapping("N92.0","58100",true));
        	icdCptMappingRepository.save(new IcdCptMapping("O80","59400",true));
        	icdCptMappingRepository.save(new IcdCptMapping("Z30.9","58300",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M17.9","73562",true));
        	 
        	icdCptMappingRepository.save(new IcdCptMapping("M16.9","73502",true));
        	icdCptMappingRepository.save(new IcdCptMapping("H04.123","68761",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R20.2","95910",true));
        	icdCptMappingRepository.save(new IcdCptMapping("L50.9","95004",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M62.81","97110",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R53.1","97112",true));
        	icdCptMappingRepository.save(new IcdCptMapping("J32.9","70486",true));
        	icdCptMappingRepository.save(new IcdCptMapping("K76.0","76705",true));
        	icdCptMappingRepository.save(new IcdCptMapping("E55.9","82306",true));
        	icdCptMappingRepository.save(new IcdCptMapping("D50.9","85025",true));
        	 
        	icdCptMappingRepository.save(new IcdCptMapping("R07.81","71101",true));
        	icdCptMappingRepository.save(new IcdCptMapping("H65.90","92557",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R45.7","90791",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R35.0","81003",true));
        	icdCptMappingRepository.save(new IcdCptMapping("M25.551","73502",true));
        	icdCptMappingRepository.save(new IcdCptMapping("J01.90","70486",true));
        	icdCptMappingRepository.save(new IcdCptMapping("R73.9","82947",true));
        	icdCptMappingRepository.save(new IcdCptMapping("Z13.1","82947",true));
        	icdCptMappingRepository.save(new IcdCptMapping("Z12.11","45378",true));
        	icdCptMappingRepository.save(new IcdCptMapping("Z12.31","77067",true));
        	 
        	log.info("ICT and CPT mapping codes seeded.");
        }
     
    }
    
  

    private void seedSystemConfig() {
        if (systemConfigRepository.count() == 0) {
            SystemConfig config = new SystemConfig();
            config.setConfigKey("CLAIM_DECISION_DELAY_MS");
            config.setConfigValue("86400000"); // 24 hours
            config.setUpdatedAt(LocalDateTime.now());
            systemConfigRepository.save(config);
            log.info("System config seeded.");
        }
    }
}
