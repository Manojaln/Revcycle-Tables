package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
   @Autowired
   private EmployeeRepository repository;
   @PostMapping("save")
   public Mono<Employee> create(@RequestBody Employee emp){
	   return repository.save(emp);
   }
   @GetMapping
   public Flux <Employee> getAll(){
	   return repository.findAll();
   }   
   @GetMapping("save2")
   public Mono<Employee> create2(@RequestBody Employee emp){
	   if(emp.getName()==null || emp.getName().isBlank()) {
		   throw new IllegalArgumentException("Employee name must not be empty");
	   }
	   return repository.save(emp);

   }
}
