package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyReactive1Application {

	public static void main(String[] args) {
		SpringApplication.run(MyReactive1Application.class, args);
	}

}
