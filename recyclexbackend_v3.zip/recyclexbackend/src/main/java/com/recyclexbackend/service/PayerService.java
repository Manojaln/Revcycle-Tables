	package com.recyclexbackend.service;
	
	
	
	import java.util.List;
	
	
	
	
	import org.springframework.stereotype.Service;
	
	
	
	import com.recyclexbackend.entity.Payer;
	
	import com.recyclexbackend.exception.ResourceNotFoundException;
	
	import com.recyclexbackend.repository.PayerRepository;
	
	
	
	import lombok.RequiredArgsConstructor;
	
	
	
	
	
	@Service
	
	@RequiredArgsConstructor
	
	public class PayerService {
	
	
	
	    private final PayerRepository payerRepository;
	
	
	
	
	
	    public Payer getById(Long id) {
	
	        return payerRepository.findById(id)
	
	                .orElseThrow(() -> new ResourceNotFoundException("Payer not found: " + id));
	
	    }
	
	
	
	
	
		public List<Payer> getAllPayers() {
	
			return payerRepository.findAll();
	
		}
	
	}