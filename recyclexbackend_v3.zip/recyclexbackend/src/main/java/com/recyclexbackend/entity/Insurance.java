package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(
        name = "insurance",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"patient_id", "policy_number"})
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Insurance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long insuranceId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payer_id", nullable = false)
    private Payer payer;

    @Column(nullable = false)
    private String policyNumber;

    private String coverageDetails;

    private BigDecimal coverageLimit;

    private String eligibilityStatus;

    private LocalDate verifiedDate;

    private Boolean isPrimary = true;

    private Boolean isDeleted = false;

    private LocalDateTime createdAt = LocalDateTime.now();
}