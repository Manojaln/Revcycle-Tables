package com.recyclexbackend.dto.response;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class PatientInsuranceResponse {

    // PATIENT
    private Long patientId;
    private String name;
    private LocalDate dob;
    private String gender;
    private String phone;
    private String email;
    private String address;

    // PAYER
    private Long payerId;
    private String payerName;

    // INSURANCE
    private Long insuranceId;
    private String policyNumber;
    private String coverageDetails;
    private BigDecimal coverageLimit;
    private String eligibilityStatus;
    private LocalDate verifiedDate;
    private Boolean isPrimary;

    private LocalDateTime createdAt;
}