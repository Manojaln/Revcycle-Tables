package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.ClaimRequest;
import com.recyclexbackend.dto.response.ClaimResponse;
import com.recyclexbackend.entity.*;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ClaimService {

    private final ClaimRepository claimRepository;
    private final EncounterRepository encounterRepository;
    private final PayerRepository payerRepository;
    private final UserRepository userRepository;
    private final ChargeEntryRepository chargeEntryRepository;
    private final ClaimStatusHistoryRepository claimStatusHistoryRepository;
    private final ClaimEditRepository claimEditRepository;
    private final ClaimScrubberService scrubberService;
    private final AuditLogService auditLogService;
    private final NotificationService notificationService;
    private final SystemConfigRepository systemConfigRepository;

    @Value("${app.claim.decision.delay.ms:86400000}")
    private long defaultDecisionDelayMs;

    public ClaimResponse createClaim(ClaimRequest request, Long billerId) {
        Encounter encounter = encounterRepository.findByEncounterIdAndIsDeletedFalse(request.getEncounterId())
                .orElseThrow(() -> new ResourceNotFoundException("Encounter not found"));

        if (!encounter.getStatus().equals("CODED")) {
            throw new BadRequestException("Encounter must be in CODED status to create claim. Current: " + encounter.getStatus());
        }

        Payer payer = payerRepository.findById(request.getPayerId())
                .orElseThrow(() -> new ResourceNotFoundException("Payer not found"));

        // Calculate total billed amount
        BigDecimal totalBilled = chargeEntryRepository.sumChargeAmountByEncounterId(request.getEncounterId());
        if (totalBilled == null) totalBilled = BigDecimal.ZERO;

        Claim claim = new Claim();
        claim.setEncounter(encounter);
        claim.setPayer(payer);
        claim.setClaimNumber("CLM-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        claim.setStatus("DRAFT");
        claim.setTotalBilledAmount(totalBilled);
        claim.setCreatedAt(LocalDateTime.now());

        if (request.getAssignedBillerId() != null) {
            User biller = userRepository.findById(request.getAssignedBillerId()).orElse(null);
            claim.setAssignedBiller(biller);
        } else {
            User biller = userRepository.findById(billerId).orElse(null);
            claim.setAssignedBiller(biller);
        }

        Claim saved = claimRepository.save(claim);
        auditLogService.log(billerId, "CLAIM", saved.getClaimId(), "CREATE", null, saved.getClaimNumber());
        return toResponse(saved);
    }

    public ClaimResponse submitClaim(Long claimId, Long billerId) {
        Claim claim = claimRepository.findByClaimIdAndIsDeletedFalse(claimId)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found"));

        if (!claim.getStatus().equals("DRAFT")) {
            throw new BadRequestException("Only DRAFT claims can be submitted");
        }

        // Run claim scrubber
        List<ClaimEdit> edits = scrubberService.scrubClaim(claim);
        boolean hasErrors = edits.stream().anyMatch(e -> "ERROR".equals(e.getSeverity()));
        if (hasErrors) {
            throw new BadRequestException("Claim has scrubbing errors. Please fix before submitting.");
        }

        String oldStatus = claim.getStatus();
        claim.setStatus("SUBMITTED");
        claim.setSubmissionDate(LocalDateTime.now());

        // Calculate decision time based on config
        long delayMs = getConfiguredDelay();
        claim.setDecisionTime(LocalDateTime.now().plusNanos(delayMs * 1_000_000L));

        claimRepository.save(claim);
        recordStatusHistory(claim, oldStatus, "SUBMITTED", billerId);
        auditLogService.log(billerId, "CLAIM", claimId, "STATUS_CHANGE", oldStatus, "SUBMITTED");

        // Notify biller
        if (claim.getAssignedBiller() != null) {
            notificationService.sendNotification(claim.getAssignedBiller().getUserId(),
                    "Claim " + claim.getClaimNumber() + " submitted for adjudication.", "CLAIM");
        }
        return toResponse(claim);
    }

    public List<ClaimResponse> getAllClaims() {
        return claimRepository.findByIsDeletedFalse().stream()
                .map(this::toResponse).collect(Collectors.toList());
    }

    public ClaimResponse getById(Long id) {
        Claim claim = claimRepository.findByClaimIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found: " + id));
        return toResponse(claim);
    }

    public List<ClaimResponse> getByStatus(String status) {
        return claimRepository.findByStatusAndIsDeletedFalse(status)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<ClaimResponse> getByBiller(Long billerId) {
        return claimRepository.findByAssignedBiller_UserIdAndIsDeletedFalse(billerId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    // Called by scheduler
    public void processDecisions() {
        List<Claim> dueClaims = claimRepository.findSubmittedClaimsDue(LocalDateTime.now());
        for (Claim claim : dueClaims) {
            // Simulate decision: 70% approve, 30% deny
            boolean approved = Math.random() > 0.3;
            String oldStatus = claim.getStatus();
            if (approved) {
                claim.setStatus("APPROVED");
                claim.setApprovedAmount(claim.getTotalBilledAmount().multiply(BigDecimal.valueOf(0.8)));
            } else {
                claim.setStatus("DENIED");
            }
            claimRepository.save(claim);

            // Status history (system user)
            recordStatusHistory(claim, oldStatus, claim.getStatus(), null);
            auditLogService.log(0L, "CLAIM", claim.getClaimId(), "STATUS_CHANGE", oldStatus, claim.getStatus());

            // Notify assigned biller
            if (claim.getAssignedBiller() != null) {
                String msg = "Claim " + claim.getClaimNumber() + " has been " + claim.getStatus();
                notificationService.sendNotification(claim.getAssignedBiller().getUserId(), msg, "CLAIM");
            }
        }
    }

    private void recordStatusHistory(Claim claim, String oldStatus, String newStatus, Long userId) {
        ClaimStatusHistory history = new ClaimStatusHistory();
        history.setClaim(claim);
        history.setOldStatus(oldStatus);
        history.setNewStatus(newStatus);
        if (userId != null) {
            userRepository.findById(userId).ifPresent(history::setChangedBy);
        }
        history.setChangedAt(LocalDateTime.now());
        claimStatusHistoryRepository.save(history);
    }

    private long getConfiguredDelay() {
        return systemConfigRepository.findById("CLAIM_DECISION_DELAY_MS")
                .map(c -> Long.parseLong(c.getConfigValue()))
                .orElse(defaultDecisionDelayMs);
    }

    public Claim getClaimEntity(Long claimId) {
        return claimRepository.findById(claimId)
                .orElseThrow(() -> new RuntimeException("Claim not found"));
    }
    
    public ClaimResponse toResponse(Claim c) {
        ClaimResponse r = new ClaimResponse();
        r.setClaimId(c.getClaimId());
        r.setEncounterId(c.getEncounter().getEncounterId());
        r.setPatientId(c.getEncounter().getPatient().getPatientId());
        r.setPatientName(c.getEncounter().getPatient().getName());
        r.setPayerId(c.getPayer().getPayerId());
        r.setPayerName(c.getPayer().getPayerName());
        r.setClaimNumber(c.getClaimNumber());
        r.setStatus(c.getStatus());
        r.setTotalBilledAmount(c.getTotalBilledAmount());
        r.setApprovedAmount(c.getApprovedAmount());
        r.setSubmissionDate(c.getSubmissionDate());
        r.setDecisionTime(c.getDecisionTime());
        r.setCreatedAt(c.getCreatedAt());
        if (c.getAssignedBiller() != null) {
            r.setAssignedBillerId(c.getAssignedBiller().getUserId());
            r.setAssignedBillerName(c.getAssignedBiller().getName());
        }
        return r;
    }
}
