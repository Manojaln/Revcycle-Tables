package com.recyclexbackend.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class ClaimDecisionScheduler {

    private final ClaimService claimService;

    // Runs every 5 minutes to check for due claims
    @Scheduled(fixedDelay = 300000)
    public void processClaimDecisions() {
        log.info("Running claim decision engine...");
        try {
            claimService.processDecisions();
        } catch (Exception e) {
            log.error("Error in claim decision engine: {}", e.getMessage());
        }
    }
}
