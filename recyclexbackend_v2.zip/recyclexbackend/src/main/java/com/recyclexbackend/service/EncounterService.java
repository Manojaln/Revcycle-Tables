package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.EncounterRequest;
import com.recyclexbackend.dto.response.EncounterResponse;
import com.recyclexbackend.entity.*;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EncounterService {

    private final EncounterRepository encounterRepository;
    private final PatientRepository patientRepository;
    private final UserRepository userRepository;
    private final EncounterStatusHistoryRepository statusHistoryRepository;
    private final AuditLogService auditLogService;

    public EncounterResponse createEncounter(EncounterRequest request, Long doctorId) {
        Patient patient = patientRepository.findByPatientIdAndIsDeletedFalse(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));
        User doctor = userRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));

        Encounter encounter = new Encounter();
        encounter.setPatient(patient);
        encounter.setDoctor(doctor);
        encounter.setServiceDate(request.getServiceDate());
        encounter.setDiagnosisNotes(request.getDiagnosisNotes());
        encounter.setStatus("OPEN");
        encounter.setCreatedAt(LocalDateTime.now());

        if (request.getAssignedCoderId() != null) {
            User coder = userRepository.findById(request.getAssignedCoderId())
                    .orElseThrow(() -> new ResourceNotFoundException("Coder not found"));
            encounter.setAssignedCoder(coder);
        }

        Encounter saved = encounterRepository.save(encounter);
        auditLogService.log(doctorId, "ENCOUNTER", saved.getEncounterId(), "CREATE", null, "OPEN");
        return toResponse(saved);
    }

    public List<EncounterResponse> getAllEncounters() {
        return encounterRepository.findByIsDeletedFalse().stream()
                .map(this::toResponse).collect(Collectors.toList());
    }

    public EncounterResponse getById(Long id) {
        Encounter enc = encounterRepository.findByEncounterIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("Encounter not found: " + id));
        return toResponse(enc);
    }

    public List<EncounterResponse> getByPatient(Long patientId) {
        return encounterRepository.findByPatient_PatientIdAndIsDeletedFalse(patientId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<EncounterResponse> getByDoctor(Long doctorId) {
        return encounterRepository.findByDoctor_UserIdAndIsDeletedFalse(doctorId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<EncounterResponse> getByCoder(Long coderId) {
        return encounterRepository.findByAssignedCoder_UserIdAndIsDeletedFalse(coderId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public EncounterResponse updateStatus(Long encounterId, String newStatus, Long updatedBy) {
        Encounter encounter = encounterRepository.findByEncounterIdAndIsDeletedFalse(encounterId)
                .orElseThrow(() -> new ResourceNotFoundException("Encounter not found"));

        String oldStatus = encounter.getStatus();
        if (oldStatus.equals(newStatus)) {
            throw new BadRequestException("Encounter is already in status: " + newStatus);
        }

        encounter.setStatus(newStatus);
        encounter.setVersion(encounter.getVersion() + 1);
        encounterRepository.save(encounter);

        // Record status history
        User changedBy = userRepository.findById(updatedBy).orElseThrow();
        EncounterStatusHistory history = new EncounterStatusHistory();
        history.setEncounter(encounter);
        history.setOldStatus(oldStatus);
        history.setNewStatus(newStatus);
        history.setChangedBy(changedBy);
        history.setChangedAt(LocalDateTime.now());
        statusHistoryRepository.save(history);

        auditLogService.log(updatedBy, "ENCOUNTER", encounterId, "STATUS_CHANGE", oldStatus, newStatus);
        return toResponse(encounter);
    }

    public EncounterResponse toResponse(Encounter e) {
        EncounterResponse r = new EncounterResponse();
        r.setEncounterId(e.getEncounterId());
        r.setPatientId(e.getPatient().getPatientId());
        r.setPatientName(e.getPatient().getName());
        r.setDoctorId(e.getDoctor().getUserId());
        r.setDoctorName(e.getDoctor().getName());
        r.setServiceDate(e.getServiceDate());
        r.setStatus(e.getStatus());
        r.setDiagnosisNotes(e.getDiagnosisNotes());
        r.setCreatedAt(e.getCreatedAt());
        if (e.getAssignedCoder() != null) {
            r.setAssignedCoderId(e.getAssignedCoder().getUserId());
            r.setAssignedCoderName(e.getAssignedCoder().getName());
        }
        return r;
    }
}
