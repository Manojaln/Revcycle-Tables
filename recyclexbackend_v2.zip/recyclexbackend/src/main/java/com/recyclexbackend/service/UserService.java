package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.CreateUserRequest;
import com.recyclexbackend.dto.response.UserResponse;
import com.recyclexbackend.entity.Role;
import com.recyclexbackend.entity.User;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.RoleRepository;
import com.recyclexbackend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditLogService auditLogService;

    public UserResponse createUser(CreateUserRequest request, Long createdBy) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already in use: " + request.getEmail());
        }
        Role role = roleRepository.findById(request.getRoleId())
                .orElseThrow(() -> new ResourceNotFoundException("Role not found: " + request.getRoleId()));

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(role);
        user.setIsActive(true);
        user.setCreatedBy(createdBy);
        user.setUpdatedBy(createdBy);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        User saved = userRepository.save(user);
        auditLogService.log(createdBy, "USER", saved.getUserId(), "CREATE", null, saved.getEmail());
        return toResponse(saved);
    }

    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    public UserResponse getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
        return toResponse(user);
    }

    public UserResponse toggleUserActive(Long userId, Long updatedBy) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userId));
        String old = user.getIsActive().toString();
        user.setIsActive(!user.getIsActive());
        user.setUpdatedBy(updatedBy);
        user.setUpdatedAt(LocalDateTime.now());
        User saved = userRepository.save(user);
        auditLogService.log(updatedBy, "USER", userId, "UPDATE", "isActive=" + old, "isActive=" + saved.getIsActive());
        return toResponse(saved);
    }

    public List<UserResponse> getUsersByRole(String roleName) {
        return userRepository.findByRole_RoleName(roleName).stream()
                .map(this::toResponse).collect(Collectors.toList());
    }

    public UserResponse toResponse(User u) {
        UserResponse r = new UserResponse();
        r.setUserId(u.getUserId());
        r.setName(u.getName());
        r.setEmail(u.getEmail());
        r.setPhone(u.getPhone());
        r.setRoleName(u.getRole().getRoleName());
        r.setIsActive(u.getIsActive());
        r.setCreatedAt(u.getCreatedAt());
        return r;
    }
}
