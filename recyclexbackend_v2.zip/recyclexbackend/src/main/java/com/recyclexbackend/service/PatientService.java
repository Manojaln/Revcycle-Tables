package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.PatientInsuranceRequest;
import com.recyclexbackend.dto.request.PatientRequest;
import com.recyclexbackend.dto.response.PatientInsuranceResponse;
import com.recyclexbackend.dto.response.PatientResponse;
import com.recyclexbackend.entity.*;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.*;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PatientService {

    private final PatientRepository patientRepository;
    private final InsuranceRepository insuranceRepository;
    private final PayerRepository payerRepository;
    private final UserRepository userRepository;
    private final AuditLogService auditLogService;

    public PatientInsuranceResponse registerPatientWithInsurance(
            PatientInsuranceRequest request,
            Long createdBy) {

        if (patientRepository.existsByNameAndDobAndPhone(
                request.getName(),
                request.getDob(),
                request.getPhone())) {

            throw new BadRequestException("Patient already registered");
        }

        User frontdesk = userRepository.findById(createdBy).orElseThrow();

        // CREATE PATIENT
        Patient patient = new Patient();
        patient.setName(request.getName());
        patient.setDob(request.getDob());
        patient.setGender(request.getGender());
        patient.setPhone(request.getPhone());
        patient.setEmail(request.getEmail());
        patient.setAddress(request.getAddress());
        patient.setAssignedFrontdesk(frontdesk);
        patient.setCreatedBy(createdBy);
        patient.setUpdatedBy(createdBy);
        patient.setCreatedAt(LocalDateTime.now());
        patient.setUpdatedAt(LocalDateTime.now());

        Patient savedPatient = patientRepository.save(patient);

        // FIND OR CREATE PAYER
        Payer payer = payerRepository
                .findByPayerName(request.getPayerName())
                .orElseGet(() -> payerRepository.save(new Payer(request.getPayerName())));

        if (insuranceRepository.findByPolicyNumber(request.getPolicyNumber()).isPresent()) {
            throw new BadRequestException("Policy number already exists");
        }

        // CREATE INSURANCE
        Insurance insurance = new Insurance();
        insurance.setPatient(savedPatient);
        insurance.setPayer(payer);
        insurance.setPolicyNumber(request.getPolicyNumber());
        insurance.setCoverageDetails(request.getCoverageDetails());
        insurance.setCoverageLimit(request.getCoverageLimit());
        insurance.setEligibilityStatus(request.getEligibilityStatus());
        insurance.setVerifiedDate(request.getVerifiedDate());
        insurance.setIsPrimary(request.getIsPrimary());
        insurance.setCreatedAt(LocalDateTime.now());

        Insurance savedInsurance = insuranceRepository.save(insurance);

        auditLogService.log(
                createdBy,
                "PATIENT",
                savedPatient.getPatientId(),
                "CREATE",
                null,
                savedPatient.getName()
        );

        return mapToResponse(savedPatient, savedInsurance, payer);
    }

    private PatientInsuranceResponse mapToResponse(
            Patient patient,
            Insurance insurance,
            Payer payer) {

        PatientInsuranceResponse r = new PatientInsuranceResponse();

        r.setPatientId(patient.getPatientId());
        r.setName(patient.getName());
        r.setDob(patient.getDob());
        r.setGender(patient.getGender());
        r.setPhone(patient.getPhone());
        r.setEmail(patient.getEmail());
        r.setAddress(patient.getAddress());

        r.setInsuranceId(insurance.getInsuranceId());
        r.setPayerId(payer.getPayerId());
        r.setPayerName(payer.getPayerName());
        r.setPolicyNumber(insurance.getPolicyNumber());
        r.setCoverageDetails(insurance.getCoverageDetails());
        r.setCoverageLimit(insurance.getCoverageLimit());
        r.setEligibilityStatus(insurance.getEligibilityStatus());
        r.setVerifiedDate(insurance.getVerifiedDate());
        r.setIsPrimary(insurance.getIsPrimary());

        r.setCreatedAt(patient.getCreatedAt());

        return r;
    }

    public List<PatientResponse> getAllPatients() {
        return patientRepository.findByIsDeletedFalse()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public PatientResponse getPatientById(Long id) {

        Patient patient = patientRepository
                .findByPatientIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));

        return toResponse(patient);
    }

    public PatientResponse updatePatient(Long id, PatientRequest request, Long updatedBy) {

        Patient patient = patientRepository
                .findByPatientIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));

        patient.setName(request.getName());
        patient.setDob(request.getDob());
        patient.setGender(request.getGender());
        patient.setPhone(request.getPhone());
        patient.setEmail(request.getEmail());
        patient.setAddress(request.getAddress());
        patient.setUpdatedBy(updatedBy);
        patient.setUpdatedAt(LocalDateTime.now());
        patient.setVersion(patient.getVersion() + 1);

        Patient saved = patientRepository.save(patient);

        return toResponse(saved);
    }

    public void deletePatient(Long id, Long deletedBy) {

        Patient patient = patientRepository
                .findByPatientIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));

        patient.setIsDeleted(true);
        patient.setUpdatedBy(deletedBy);

        patientRepository.save(patient);
    }

    private PatientResponse toResponse(Patient p) {

        PatientResponse r = new PatientResponse();

        r.setPatientId(p.getPatientId());
        r.setName(p.getName());
        r.setDob(p.getDob());
        r.setGender(p.getGender());
        r.setPhone(p.getPhone());
        r.setEmail(p.getEmail());
        r.setAddress(p.getAddress());
        r.setCreatedAt(p.getCreatedAt());

        if (p.getAssignedFrontdesk() != null) {
            r.setAssignedFrontdeskId(p.getAssignedFrontdesk().getUserId());
            r.setAssignedFrontdeskName(p.getAssignedFrontdesk().getName());
        }

        return r;
    }
}