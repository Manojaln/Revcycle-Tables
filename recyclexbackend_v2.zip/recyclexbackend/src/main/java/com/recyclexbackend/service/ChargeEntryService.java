package com.recyclexbackend.service;

import com.recyclexbackend.dto.request.ChargeEntryRequest;
import com.recyclexbackend.dto.response.ChargeEntryResponse;
import com.recyclexbackend.entity.*;
import com.recyclexbackend.exception.BadRequestException;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ChargeEntryService {

    private final ChargeEntryRepository chargeEntryRepository;
    private final EncounterRepository encounterRepository;
    private final IcdMasterRepository icdMasterRepository;
    private final CptMasterRepository cptMasterRepository;
    private final AuditLogService auditLogService;

    public ChargeEntryResponse addCharge(ChargeEntryRequest request, Long coderId) {
        Encounter encounter = encounterRepository.findByEncounterIdAndIsDeletedFalse(request.getEncounterId())
                .orElseThrow(() -> new ResourceNotFoundException("Encounter not found"));

        if (!encounter.getStatus().equals("OPEN") && !encounter.getStatus().equals("CODED")) {
            throw new BadRequestException("Cannot add charges to encounter in status: " + encounter.getStatus());
        }

        IcdMaster icd = icdMasterRepository.findById(request.getIcdCode())
                .orElseThrow(() -> new ResourceNotFoundException("ICD code not found: " + request.getIcdCode()));
        CptMaster cpt = cptMasterRepository.findById(request.getCptCode())
                .orElseThrow(() -> new ResourceNotFoundException("CPT code not found: " + request.getCptCode()));

        BigDecimal chargeAmount = request.getChargeAmount() != null
                ? request.getChargeAmount()
                : cpt.getDefaultCharge().multiply(BigDecimal.valueOf(request.getUnits()));

        ChargeEntry entry = new ChargeEntry();
        entry.setEncounter(encounter);
        entry.setIcd(icd);
        entry.setCpt(cpt);
        entry.setUnits(request.getUnits());
        entry.setChargeAmount(chargeAmount);
        entry.setCreatedAt(LocalDateTime.now());

        ChargeEntry saved = chargeEntryRepository.save(entry);

        // Update encounter status to CODED if not already
        if (encounter.getStatus().equals("OPEN")) {
            encounter.setStatus("CODED");
            encounterRepository.save(encounter);
        }

        auditLogService.log(coderId, "CHARGE_ENTRY", saved.getChargeId(), "CREATE",
                null, cpt.getCptCode() + " x" + request.getUnits());
        return toResponse(saved);
    }

    public List<ChargeEntryResponse> getChargesByEncounter(Long encounterId) {
        return chargeEntryRepository.findByEncounter_EncounterId(encounterId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public void deleteCharge(Long chargeId, Long deletedBy) {
        ChargeEntry entry = chargeEntryRepository.findById(chargeId)
                .orElseThrow(() -> new ResourceNotFoundException("Charge not found: " + chargeId));
        chargeEntryRepository.delete(entry);
        auditLogService.log(deletedBy, "CHARGE_ENTRY", chargeId, "DELETE", entry.getCpt().getCptCode(), null);
    }

    public ChargeEntryResponse toResponse(ChargeEntry c) {
        ChargeEntryResponse r = new ChargeEntryResponse();
        r.setChargeId(c.getChargeId());
        r.setEncounterId(c.getEncounter().getEncounterId());
        r.setIcdCode(c.getIcd().getIcdCode());
        r.setIcdDescription(c.getIcd().getDescription());
        r.setCptCode(c.getCpt().getCptCode());
        r.setCptDescription(c.getCpt().getDescription());
        r.setUnits(c.getUnits());
        r.setChargeAmount(c.getChargeAmount());
        r.setCreatedAt(c.getCreatedAt());
        return r;
    }
}
