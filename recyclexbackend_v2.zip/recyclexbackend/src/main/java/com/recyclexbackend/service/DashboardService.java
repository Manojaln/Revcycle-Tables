package com.recyclexbackend.service;

import com.recyclexbackend.dto.response.DashboardResponse;
import com.recyclexbackend.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final ClaimRepository claimRepository;
    private final PaymentRepository paymentRepository;
    private final DenialRepository denialRepository;

    public DashboardResponse getDashboard() {
        DashboardResponse dash = new DashboardResponse();

        // Financial
        BigDecimal totalBilled = claimRepository.findByIsDeletedFalse().stream()
                .filter(c -> c.getTotalBilledAmount() != null)
                .map(c -> c.getTotalBilledAmount())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        dash.setTotalBilledAmount(totalBilled);
        dash.setTotalInsurancePayments(paymentRepository.sumInsurancePayments());
        dash.setTotalPatientPayments(paymentRepository.sumPatientPayments());
        dash.setTotalAdjustments(paymentRepository.sumAdjustments());

        // Claim counts
        long total = claimRepository.countTotal();
        long approved = claimRepository.countByStatus("APPROVED");
        long denied = claimRepository.countByStatus("DENIED");
        long submitted = claimRepository.countByStatus("SUBMITTED");
        long paid = claimRepository.countByStatus("PAID");

        dash.setTotalClaims(total);
        dash.setApprovedClaims(approved);
        dash.setDeniedClaims(denied);
        dash.setSubmittedClaims(submitted);
        dash.setPaidClaims(paid);

        // Denial rate
        dash.setDenialRate(total > 0 ? (double) denied / total * 100 : 0.0);

        // Denial breakdown
        Map<String, Long> byReason = new HashMap<>();
        for (Object[] row : denialRepository.countByReasonCode()) {
            byReason.put((String) row[0], (Long) row[1]);
        }
        dash.setDenialsByReasonCode(byReason);

        Map<String, Long> byCategory = new HashMap<>();
        for (Object[] row : denialRepository.countByCategory()) {
            byCategory.put((String) row[0], (Long) row[1]);
        }
        dash.setDenialsByCategory(byCategory);

        return dash;
    }
}
