package com.recyclexbackend.dto.response;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class UserResponse {
    private Long userId;
    private String name;
    private String email;
    private String phone;
    private String roleName;
    private Boolean isActive;
    private LocalDateTime createdAt;
}
