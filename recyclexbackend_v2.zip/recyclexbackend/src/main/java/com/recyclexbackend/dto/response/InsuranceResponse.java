package com.recyclexbackend.dto.response;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class InsuranceResponse {
    private Long insuranceId;
    private Long patientId;
    private String patientName;
    private Long payerId;
    private String payerName;
    private String policyNumber;
    private String coverageDetails;
    private BigDecimal coverageLimit;
    private String eligibilityStatus;
    private LocalDate verifiedDate;
    private Boolean isPrimary;
    private LocalDateTime createdAt;
}
