package com.recyclexbackend.dto.response;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ChargeEntryResponse {
    private Long chargeId;
    private Long encounterId;
    private String icdCode;
    private String icdDescription;
    private String cptCode;
    private String cptDescription;
    private Integer units;
    private BigDecimal chargeAmount;
    private LocalDateTime createdAt;
}
