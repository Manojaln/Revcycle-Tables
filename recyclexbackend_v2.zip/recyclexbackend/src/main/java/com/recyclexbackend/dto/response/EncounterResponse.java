package com.recyclexbackend.dto.response;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class EncounterResponse {
    private Long encounterId;
    private Long patientId;
    private String patientName;
    private Long doctorId;
    private String doctorName;
    private LocalDate serviceDate;
    private String status;
    private String diagnosisNotes;
    private Long assignedCoderId;
    private String assignedCoderName;
    private LocalDateTime createdAt;
}
