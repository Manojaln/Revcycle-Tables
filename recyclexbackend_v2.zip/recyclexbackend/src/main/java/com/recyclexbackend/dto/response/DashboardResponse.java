package com.recyclexbackend.dto.response;

import lombok.Data;
import java.math.BigDecimal;
import java.util.Map;

@Data
public class DashboardResponse {
    // Financial Metrics
    private BigDecimal totalBilledAmount;
    private BigDecimal totalInsurancePayments;
    private BigDecimal totalPatientPayments;
    private BigDecimal totalAdjustments;

    // Claim Metrics
    private long totalClaims;
    private long approvedClaims;
    private long deniedClaims;
    private long submittedClaims;
    private long paidClaims;

    // Denial Analytics
    private double denialRate;
    private Map<String, Long> denialsByReasonCode;
    private Map<String, Long> denialsByCategory;
}
