package com.recyclexbackend.dto.response;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class NotificationResponse {
    private Long notificationId;
    private String message;
    private String category;
    private String status;
    private LocalDateTime createdAt;
}
