package com.recyclexbackend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class InsuranceRequest {
    @NotNull
    private Long patientId;

    @NotNull
    private String payerName;

    @NotBlank
    private String policyNumber;

    private String coverageDetails;
    private BigDecimal coverageLimit;
    private String eligibilityStatus;
    private LocalDate verifiedDate;
    private Boolean isPrimary = true;

}
