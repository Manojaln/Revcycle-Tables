package com.recyclexbackend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class DenialRequest {
    @NotNull
    private Long claimId;

    @NotNull
    private LocalDate denialDate;

    @NotBlank
    private String reasonCode;

    private String category;

    private Long assignedAnalystId;
}
