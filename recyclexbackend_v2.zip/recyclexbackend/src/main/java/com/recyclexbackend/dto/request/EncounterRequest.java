package com.recyclexbackend.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class EncounterRequest {
    @NotNull
    private Long patientId;

    @NotNull
    private LocalDate serviceDate;

    private String diagnosisNotes;

    private Long assignedCoderId;
}
