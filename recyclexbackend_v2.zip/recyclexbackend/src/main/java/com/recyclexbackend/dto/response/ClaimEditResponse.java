package com.recyclexbackend.dto.response;

public class ClaimEditResponse {
	 
    private String ruleCode;
    private String message;
    private String severity;
 
    public ClaimEditResponse(String ruleCode, String message, String severity) {
        this.ruleCode = ruleCode;
        this.message = message;
        this.severity = severity;
    }
 
    public String getRuleCode() { return ruleCode; }
    public String getMessage() { return message; }
    public String getSeverity() { return severity; }
}