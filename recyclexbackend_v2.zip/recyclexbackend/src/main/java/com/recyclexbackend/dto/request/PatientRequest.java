package com.recyclexbackend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class PatientRequest {
    @NotBlank
    private String name; 

    @NotNull
    private LocalDate dob;

    @NotBlank
    private String gender;

    @NotBlank
    private String phone;

    private String email;
    private String address;

    @NotNull
    private Long payerId;

    @NotBlank
    private String policyNumber;

    private String coverageDetails;
    private BigDecimal coverageLimit;
    private String eligibilityStatus;
    private LocalDate verifiedDate;
    private Boolean isPrimary = true;
    

}
