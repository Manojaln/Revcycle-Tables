package com.recyclexbackend.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class PaymentRequest {
    @NotNull
    private Long claimId;

    private String transactionReference;

    private BigDecimal insurancePayment = BigDecimal.ZERO;
    private BigDecimal patientPayment = BigDecimal.ZERO;
    private BigDecimal adjustmentAmount = BigDecimal.ZERO;

    @NotNull
    private String source;

    @NotNull
    private LocalDate datePosted;
}
