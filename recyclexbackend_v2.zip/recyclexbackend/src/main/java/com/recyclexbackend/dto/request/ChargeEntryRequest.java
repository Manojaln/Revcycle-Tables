package com.recyclexbackend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class ChargeEntryRequest {
    @NotNull
    private Long encounterId;

    @NotBlank
    private String icdCode;

    @NotBlank
    private String cptCode;

    @NotNull
    private Integer units;

    private BigDecimal chargeAmount; // optional override; defaults to CPT default charge * units
}
