package com.recyclexbackend.dto.response;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class DenialResponse {
    private Long denialId;
    private Long claimId;
    private String claimNumber;
    private LocalDate denialDate;
    private String reasonCode;
    private String category;
    private String status;
    private Long assignedAnalystId;
    private String assignedAnalystName;
    private LocalDateTime createdAt;
}
