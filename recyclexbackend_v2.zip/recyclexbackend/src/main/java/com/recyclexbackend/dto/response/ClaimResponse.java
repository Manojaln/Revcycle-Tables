package com.recyclexbackend.dto.response;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ClaimResponse {
    private Long claimId;
    private Long encounterId;
    private Long patientId;
    private String patientName;
    private Long payerId;
    private String payerName;
    private String claimNumber;
    private String status;
    private BigDecimal totalBilledAmount;
    private BigDecimal approvedAmount;
    private LocalDateTime submissionDate;
    private LocalDateTime decisionTime;
    private Long assignedBillerId;
    private String assignedBillerName;
    private LocalDateTime createdAt;
}
