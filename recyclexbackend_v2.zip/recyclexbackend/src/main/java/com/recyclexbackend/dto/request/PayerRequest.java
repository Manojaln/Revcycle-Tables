package com.recyclexbackend.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PayerRequest {
    @NotBlank
    private String payerName;
}
