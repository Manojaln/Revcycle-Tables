package com.recyclexbackend.dto.response;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class PaymentResponse {
    private Long paymentId;
    private Long claimId;
    private String claimNumber;
    private String transactionReference;
    private BigDecimal insurancePayment;
    private BigDecimal patientPayment;
    private BigDecimal adjustmentAmount;
    private String source;
    private LocalDate datePosted;
    private String postedBy;
    private LocalDateTime createdAt;
}
