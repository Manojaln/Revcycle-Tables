package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "charge_entries")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class ChargeEntry {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long chargeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "encounter_id")
    private Encounter encounter;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "icd_code")
    private IcdMaster icd;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cpt_code")
    private CptMaster cpt;

    private Integer units;
    private BigDecimal chargeAmount;

    private LocalDateTime createdAt = LocalDateTime.now();
}
