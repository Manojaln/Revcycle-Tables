package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "system_config")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class SystemConfig {
    @Id
    private String configKey;

    private String configValue;

    private Long updatedBy;

    private LocalDateTime updatedAt = LocalDateTime.now();
}
