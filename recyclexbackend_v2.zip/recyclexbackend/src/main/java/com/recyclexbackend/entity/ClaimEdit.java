package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "claim_edits")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class ClaimEdit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long editId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "claim_id")
    private Claim claim;

    private String editType;
    private String editMessage;
    private String severity; // ERROR, WARNING, INFO

    private LocalDateTime createdAt = LocalDateTime.now();
}
