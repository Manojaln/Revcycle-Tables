package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "icd_master")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class IcdMaster {
    @Id
    private String icdCode;

    private String description;
    private Boolean isActive = true;
}
