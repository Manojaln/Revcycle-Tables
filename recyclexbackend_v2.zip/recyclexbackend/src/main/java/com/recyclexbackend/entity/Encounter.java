package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "encounters")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Encounter {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long encounterId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id")
    private Patient patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doctor_id")
    private User doctor;

    private LocalDate serviceDate;
    private String status; // OPEN, CODED, BILLED, CLOSED

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_coder_id")
    private User assignedCoder;

    @Column(columnDefinition = "TEXT")
    private String diagnosisNotes;

    private Integer version = 1;
    private Boolean isDeleted = false;

    private LocalDateTime createdAt = LocalDateTime.now();
}
