package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Entity
@Table(name = "cpt_master")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class CptMaster {
    @Id
    private String cptCode;

    private String description;
    private BigDecimal defaultCharge;
    private Boolean isActive = true;
}
