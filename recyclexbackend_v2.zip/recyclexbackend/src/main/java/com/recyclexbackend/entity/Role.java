package com.recyclexbackend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "roles")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Role {
    @Id
    private Long roleId;

    @Column(unique = true, nullable = false)
    private String roleName;

    private LocalDateTime createdAt = LocalDateTime.now();
}
