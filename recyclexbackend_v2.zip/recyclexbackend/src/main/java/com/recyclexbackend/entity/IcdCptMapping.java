package com.recyclexbackend.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="icd_cpt_mapping")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IcdCptMapping {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private String icdCode;
    private String cptCode;
    private boolean isValid=true;
    
    public IcdCptMapping(String icdCode, String cptCode, Boolean isValid) {
    	this.icdCode=icdCode;
    	this.cptCode=cptCode;
    	this.isValid=isValid;
    }
}
