package com.recyclexbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class ReCycleXApplication {
    public static void main(String[] args) {
        SpringApplication.run(ReCycleXApplication.class, args);
    }
}
