package com.recyclexbackend.controller;

import com.recyclexbackend.dto.request.ChargeEntryRequest;
import com.recyclexbackend.dto.response.ApiResponse;
import com.recyclexbackend.dto.response.ChargeEntryResponse;
import com.recyclexbackend.entity.CptMaster;
import com.recyclexbackend.entity.IcdMaster;
import com.recyclexbackend.repository.CptMasterRepository;
import com.recyclexbackend.repository.IcdMasterRepository;
import com.recyclexbackend.service.ChargeEntryService;
import com.recyclexbackend.util.SecurityHelper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/charges")
@RequiredArgsConstructor
public class ChargeEntryController {

    private final ChargeEntryService chargeEntryService;
    private final IcdMasterRepository icdMasterRepository;
    private final CptMasterRepository cptMasterRepository;
    private final SecurityHelper securityHelper;

    @PostMapping
    public ResponseEntity<ApiResponse<ChargeEntryResponse>> addCharge(
            @Valid @RequestBody ChargeEntryRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Charge added",
                chargeEntryService.addCharge(request, securityHelper.getCurrentUserId())));
    }

    @GetMapping("/encounter/{encounterId}")
    public ResponseEntity<ApiResponse<List<ChargeEntryResponse>>> getByEncounter(
            @PathVariable Long encounterId) {
        return ResponseEntity.ok(ApiResponse.success(chargeEntryService.getChargesByEncounter(encounterId)));
    }

    @DeleteMapping("/{chargeId}")
    public ResponseEntity<ApiResponse<Void>> deleteCharge(@PathVariable Long chargeId) {
        chargeEntryService.deleteCharge(chargeId, securityHelper.getCurrentUserId());
        return ResponseEntity.ok(ApiResponse.success("Charge deleted", null));
    }

    @GetMapping("/icd")
    public ResponseEntity<ApiResponse<List<IcdMaster>>> searchIcd(
            @RequestParam(required = false) String keyword) {
        List<IcdMaster> result = keyword != null
                ? icdMasterRepository.findByDescriptionContainingIgnoreCase(keyword)
                : icdMasterRepository.findByIsActiveTrue();
        return ResponseEntity.ok(ApiResponse.success(result));
    }

    @GetMapping("/cpt")
    public ResponseEntity<ApiResponse<List<CptMaster>>> searchCpt(
            @RequestParam(required = false) String keyword) {
        List<CptMaster> result = keyword != null
                ? cptMasterRepository.findByDescriptionContainingIgnoreCase(keyword)
                : cptMasterRepository.findByIsActiveTrue();
        return ResponseEntity.ok(ApiResponse.success(result));
    }
}
