	package com.recyclexbackend.controller;
	
	import com.recyclexbackend.dto.request.PatientInsuranceRequest;
	import com.recyclexbackend.dto.request.PatientRequest;
	import com.recyclexbackend.dto.response.ApiResponse;
	import com.recyclexbackend.dto.response.InsuranceResponse;
	import com.recyclexbackend.dto.response.PatientInsuranceResponse;
	import com.recyclexbackend.dto.response.PatientResponse;
	import com.recyclexbackend.service.InsuranceService;
	import com.recyclexbackend.service.PatientService;
	import com.recyclexbackend.util.SecurityHelper;
	import jakarta.validation.Valid;
	import lombok.RequiredArgsConstructor;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.*;
	
	import java.util.List;
	
	@RestController
	@RequestMapping("/api/patients")
	@RequiredArgsConstructor
	public class PatientController {
	
	    private final PatientService patientService;
	    private final InsuranceService insuranceService;
	    private final SecurityHelper securityHelper;
	
	    @PostMapping("/register")
	    public ResponseEntity<ApiResponse<PatientInsuranceResponse>> register(
	            @Valid @RequestBody PatientInsuranceRequest request) {

	        return ResponseEntity.ok(
	                ApiResponse.success(
	                        "Patient and Insurance registered",
	                        patientService.registerPatientWithInsurance(
	                                request,
	                                securityHelper.getCurrentUserId()
	                        )
	                )
	        );
	    }

	    @GetMapping
	    public ResponseEntity<ApiResponse<List<PatientResponse>>> getAll() {
	        return ResponseEntity.ok(ApiResponse.success(patientService.getAllPatients()));
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<ApiResponse<PatientResponse>> getById(@PathVariable Long id) {
	        return ResponseEntity.ok(ApiResponse.success(patientService.getPatientById(id)));
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<ApiResponse<PatientResponse>> update(
	            @PathVariable Long id,
	            @Valid @RequestBody PatientRequest request) {

	        return ResponseEntity.ok(ApiResponse.success(
	                "Patient updated",
	                patientService.updatePatient(id, request, securityHelper.getCurrentUserId())
	        ));
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
	        patientService.deletePatient(id, securityHelper.getCurrentUserId());
	        return ResponseEntity.ok(ApiResponse.success("Patient deleted", null));
	    }	
//	    // Insurance
//	    @PostMapping("/insurance")
//	    public ResponseEntity<ApiResponse<InsuranceResponse>> addInsurance(@Valid @RequestBody InsuranceRequest request) {
//	        return ResponseEntity.ok(ApiResponse.success("Insurance added",
//	                insuranceService.addInsurance(request, securityHelper.getCurrentUserId())));
//	    }
//	
	    @GetMapping("/{patientId}/insurance")
	    public ResponseEntity<ApiResponse<List<InsuranceResponse>>> getInsurance(@PathVariable Long patientId) {
	        return ResponseEntity.ok(ApiResponse.success(insuranceService.getInsuranceByPatient(patientId)));
	    }
	}
