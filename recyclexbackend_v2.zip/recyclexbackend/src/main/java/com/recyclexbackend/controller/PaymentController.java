package com.recyclexbackend.controller;

import com.recyclexbackend.dto.request.PaymentRequest;
import com.recyclexbackend.dto.response.ApiResponse;
import com.recyclexbackend.dto.response.PaymentResponse;
import com.recyclexbackend.service.PaymentService;
import com.recyclexbackend.util.SecurityHelper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;
    private final SecurityHelper securityHelper;

    @PostMapping
    public ResponseEntity<ApiResponse<PaymentResponse>> recordPayment(
            @Valid @RequestBody PaymentRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Payment recorded",
                paymentService.recordPayment(request, securityHelper.getCurrentUserId())));
    }

    @GetMapping("/claim/{claimId}")
    public ResponseEntity<ApiResponse<List<PaymentResponse>>> getByClaimId(@PathVariable Long claimId) {
        return ResponseEntity.ok(ApiResponse.success(paymentService.getPaymentsByClaim(claimId)));
    }
}
