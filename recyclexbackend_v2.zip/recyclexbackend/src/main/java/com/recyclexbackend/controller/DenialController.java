package com.recyclexbackend.controller;

import com.recyclexbackend.dto.request.DenialRequest;
import com.recyclexbackend.dto.response.ApiResponse;
import com.recyclexbackend.dto.response.DenialResponse;
import com.recyclexbackend.service.DenialService;
import com.recyclexbackend.util.SecurityHelper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/denials")
@RequiredArgsConstructor
public class DenialController {

    private final DenialService denialService;
    private final SecurityHelper securityHelper;

    @PostMapping
    public ResponseEntity<ApiResponse<DenialResponse>> createDenial(
            @Valid @RequestBody DenialRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Denial recorded",
                denialService.createDenial(request, securityHelper.getCurrentUserId())));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<DenialResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(denialService.getAllDenials()));
    }

    @GetMapping("/claim/{claimId}")
    public ResponseEntity<ApiResponse<List<DenialResponse>>> getByClaim(@PathVariable Long claimId) {
        return ResponseEntity.ok(ApiResponse.success(denialService.getDenialsByClaim(claimId)));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<DenialResponse>>> getMyDenials() {
        return ResponseEntity.ok(ApiResponse.success(
                denialService.getDenialsByAnalyst(securityHelper.getCurrentUserId())));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<DenialResponse>> updateStatus(
            @PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(ApiResponse.success("Status updated",
                denialService.updateDenialStatus(id, status, securityHelper.getCurrentUserId())));
    }
}
