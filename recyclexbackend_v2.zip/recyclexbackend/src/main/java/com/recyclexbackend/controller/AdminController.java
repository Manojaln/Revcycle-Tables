package com.recyclexbackend.controller;

import com.recyclexbackend.dto.request.CreateUserRequest;
import com.recyclexbackend.dto.request.PayerRequest;
import com.recyclexbackend.dto.response.ApiResponse;
import com.recyclexbackend.dto.response.UserResponse;
import com.recyclexbackend.entity.AuditLog;
import com.recyclexbackend.entity.Payer;
import com.recyclexbackend.entity.SystemConfig;
import com.recyclexbackend.exception.ResourceNotFoundException;
import com.recyclexbackend.repository.SystemConfigRepository;
import com.recyclexbackend.service.AuditLogService;
import com.recyclexbackend.service.PayerService;
import com.recyclexbackend.service.UserService;
import com.recyclexbackend.util.SecurityHelper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminController {

    private final UserService userService;
    private final PayerService payerService;
    private final AuditLogService auditLogService;
    private final SystemConfigRepository systemConfigRepository;
    private final SecurityHelper securityHelper;

    // --- User Management ---
    @PostMapping("/users")
    public ResponseEntity<ApiResponse<UserResponse>> createUser(@Valid @RequestBody CreateUserRequest request) {
        return ResponseEntity.ok(ApiResponse.success("User created",
                userService.createUser(request, securityHelper.getCurrentUserId())));
    }

    @GetMapping("/users")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAllUsers() {
        return ResponseEntity.ok(ApiResponse.success(userService.getAllUsers()));
    }

    @GetMapping("/users/{id}")
    public ResponseEntity<ApiResponse<UserResponse>> getUser(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(userService.getUserById(id)));
    }

    @PatchMapping("/users/{id}/toggle-active")
    public ResponseEntity<ApiResponse<UserResponse>> toggleUserActive(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("User status updated",
                userService.toggleUserActive(id, securityHelper.getCurrentUserId())));
    }

    @GetMapping("/users/role/{roleName}")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getUsersByRole(@PathVariable String roleName) {
        return ResponseEntity.ok(ApiResponse.success(userService.getUsersByRole(roleName)));
    }


    @GetMapping("/payers")
    public ResponseEntity<ApiResponse<List<Payer>>> getAllPayers() {
        return ResponseEntity.ok(ApiResponse.success(payerService.getAllPayers()));
    }

    // --- System Config ---
    @PutMapping("/config/{key}")
    public ResponseEntity<ApiResponse<SystemConfig>> updateConfig(
            @PathVariable String key,
            @RequestBody String value) {

        // Only allow valid config
        if (!"CLAIM_DECISION_DELAY_MS".equals(key)) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Invalid configuration key"));
        }

        SystemConfig config = systemConfigRepository.findById(key)
                .orElse(new SystemConfig());

        config.setConfigKey(key);
        config.setConfigValue(value.replaceAll("\"", "").trim());
        config.setUpdatedBy(securityHelper.getCurrentUserId());
        config.setUpdatedAt(LocalDateTime.now());

        systemConfigRepository.save(config);

        return ResponseEntity.ok(
                ApiResponse.success("Config updated", config)
        );
    }

    @GetMapping("/config")
    public ResponseEntity<ApiResponse<List<SystemConfig>>> getAllConfigs() {
        return ResponseEntity.ok(ApiResponse.success(systemConfigRepository.findAll()));
    }

    // --- Audit Logs ---
    @GetMapping("/audit-logs")
    public ResponseEntity<ApiResponse<List<AuditLog>>> getRecentAuditLogs(
            @RequestParam(defaultValue = "100") int limit) {
        return ResponseEntity.ok(ApiResponse.success(auditLogService.getRecentLogs(limit)));
    }

    @GetMapping("/audit-logs/entity/{type}/{id}")
    public ResponseEntity<ApiResponse<List<AuditLog>>> getAuditByEntity(
            @PathVariable String type, @PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(auditLogService.getLogsByEntity(type, id)));
    }
}
