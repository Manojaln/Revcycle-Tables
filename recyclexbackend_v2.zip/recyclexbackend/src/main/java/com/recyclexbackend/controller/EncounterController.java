package com.recyclexbackend.controller;

import com.recyclexbackend.dto.request.EncounterRequest;
import com.recyclexbackend.dto.response.ApiResponse;
import com.recyclexbackend.dto.response.EncounterResponse;
import com.recyclexbackend.service.EncounterService;
import com.recyclexbackend.util.SecurityHelper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/encounters")
@RequiredArgsConstructor
public class EncounterController {

    private final EncounterService encounterService;
    private final SecurityHelper securityHelper;

    @PostMapping
    public ResponseEntity<ApiResponse<EncounterResponse>> create(@Valid @RequestBody EncounterRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Encounter created",
                encounterService.createEncounter(request, securityHelper.getCurrentUserId())));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<EncounterResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(encounterService.getAllEncounters()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<EncounterResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(encounterService.getById(id)));
    }

    @GetMapping("/patient/{patientId}")
    public ResponseEntity<ApiResponse<List<EncounterResponse>>> getByPatient(@PathVariable Long patientId) {
        return ResponseEntity.ok(ApiResponse.success(encounterService.getByPatient(patientId)));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<EncounterResponse>>> getMine() {
        return ResponseEntity.ok(ApiResponse.success(
                encounterService.getByDoctor(securityHelper.getCurrentUserId())));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<EncounterResponse>> updateStatus(
            @PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(ApiResponse.success("Status updated",
                encounterService.updateStatus(id, status, securityHelper.getCurrentUserId())));
    }
}
