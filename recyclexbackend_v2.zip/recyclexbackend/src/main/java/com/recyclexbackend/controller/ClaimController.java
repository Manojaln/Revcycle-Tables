package com.recyclexbackend.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.recyclexbackend.dto.request.ClaimRequest;
import com.recyclexbackend.dto.response.ApiResponse;
import com.recyclexbackend.dto.response.ClaimEditResponse;
import com.recyclexbackend.dto.response.ClaimResponse;
import com.recyclexbackend.entity.Claim;
import com.recyclexbackend.entity.ClaimEdit;
import com.recyclexbackend.entity.ClaimStatusHistory;
import com.recyclexbackend.repository.ClaimEditRepository;
import com.recyclexbackend.repository.ClaimStatusHistoryRepository;
import com.recyclexbackend.service.ClaimScrubberService;
import com.recyclexbackend.service.ClaimService;
import com.recyclexbackend.util.SecurityHelper;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/claims")
@RequiredArgsConstructor
public class ClaimController {

    private final ClaimService claimService;
    private final ClaimEditRepository claimEditRepository;
    private final ClaimStatusHistoryRepository claimStatusHistoryRepository;
    private final SecurityHelper securityHelper;
    private final ClaimScrubberService claimScrubberService;
    
    

    @PostMapping
    public ResponseEntity<ApiResponse<ClaimResponse>> createClaim(@Valid @RequestBody ClaimRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Claim created",
                claimService.createClaim(request, securityHelper.getCurrentUserId())));
    }

    @PostMapping("/{id}/submit")
    public ResponseEntity<ApiResponse<ClaimResponse>> submitClaim(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Claim submitted",
                claimService.submitClaim(id, securityHelper.getCurrentUserId())));
    }
    
    @PostMapping("/{claimId}/scrub")
    public ResponseEntity<ApiResponse<?>> scrubClaim(@PathVariable Long claimId) {
     
        Claim claim = claimService.getClaimEntity(claimId);
     
        List<ClaimEdit> edits = claimScrubberService.scrubClaim(claim);
     
        List<ClaimEditResponse> response =
                edits.stream()
                     .map(e -> new ClaimEditResponse(
                            e.getEditType(),
                            e.getEditMessage(),
                            e.getSeverity()))
                     .toList();
     
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<ClaimResponse>>> getAllClaims() {
        return ResponseEntity.ok(ApiResponse.success(claimService.getAllClaims()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ClaimResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(claimService.getById(id)));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse<List<ClaimResponse>>> getByStatus(@PathVariable String status) {
        return ResponseEntity.ok(ApiResponse.success(claimService.getByStatus(status)));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<ClaimResponse>>> getMyClaims() {
        return ResponseEntity.ok(ApiResponse.success(
                claimService.getByBiller(securityHelper.getCurrentUserId())));
    }

    @GetMapping("/{id}/edits")
    public ResponseEntity<ApiResponse<List<ClaimEdit>>> getClaimEdits(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(claimEditRepository.findByClaim_ClaimId(id)));
    }

    @GetMapping("/{id}/history")
    public ResponseEntity<ApiResponse<List<ClaimStatusHistory>>> getClaimHistory(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(
                claimStatusHistoryRepository.findByClaim_ClaimIdOrderByChangedAtDesc(id)));
    }

    
    
}
