package com.recyclexbackend.repository;

import com.recyclexbackend.entity.ClaimStatusHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ClaimStatusHistoryRepository extends JpaRepository<ClaimStatusHistory, Long> {
    List<ClaimStatusHistory> findByClaim_ClaimIdOrderByChangedAtDesc(Long claimId);
}
