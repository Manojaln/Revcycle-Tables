package com.recyclexbackend.repository;

import com.recyclexbackend.entity.ChargeEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.math.BigDecimal;
import java.util.List;

public interface ChargeEntryRepository extends JpaRepository<ChargeEntry, Long> {
    List<ChargeEntry> findByEncounter_EncounterId(Long encounterId);

    @Query("SELECT SUM(c.chargeAmount) FROM ChargeEntry c WHERE c.encounter.encounterId = :encounterId")
    BigDecimal sumChargeAmountByEncounterId(Long encounterId);
}
