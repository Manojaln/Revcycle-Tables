package com.recyclexbackend.repository;

import com.recyclexbackend.entity.EncounterStatusHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EncounterStatusHistoryRepository extends JpaRepository<EncounterStatusHistory, Long> {
    List<EncounterStatusHistory> findByEncounter_EncounterIdOrderByChangedAtDesc(Long encounterId);
}
