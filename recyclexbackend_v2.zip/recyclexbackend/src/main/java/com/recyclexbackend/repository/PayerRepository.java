package com.recyclexbackend.repository;

import com.recyclexbackend.entity.Payer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface PayerRepository extends JpaRepository<Payer, Long> {
	Optional<Payer> findByPayerName(String payerName);
}
