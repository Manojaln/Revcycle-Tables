package com.recyclexbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.recyclexbackend.entity.IcdCptMapping;

public interface IcdCptMappingRepository extends JpaRepository <IcdCptMapping, Long> {
	 
    boolean existsByIcdCodeAndCptCodeAndIsValidTrue(String icdCode, String cptCode);
}