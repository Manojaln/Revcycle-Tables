package com.recyclexbackend.repository;

import com.recyclexbackend.entity.ClaimEdit;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ClaimEditRepository extends JpaRepository<ClaimEdit, Long> {
    List<ClaimEdit> findByClaim_ClaimId(Long claimId);
    boolean existsByClaim_ClaimIdAndSeverity(Long claimId, String severity);
}
