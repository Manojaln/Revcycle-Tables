package com.recyclexbackend.repository;

import com.recyclexbackend.entity.IcdMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface IcdMasterRepository extends JpaRepository<IcdMaster, String> {
    List<IcdMaster> findByIsActiveTrue();
    List<IcdMaster> findByDescriptionContainingIgnoreCase(String keyword);
}
