package com.recyclexbackend.repository;

import com.recyclexbackend.entity.Encounter;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface EncounterRepository extends JpaRepository<Encounter, Long> {
    List<Encounter> findByIsDeletedFalse();
    Optional<Encounter> findByEncounterIdAndIsDeletedFalse(Long id);
    List<Encounter> findByPatient_PatientIdAndIsDeletedFalse(Long patientId);
    List<Encounter> findByDoctor_UserIdAndIsDeletedFalse(Long doctorId);
    List<Encounter> findByAssignedCoder_UserIdAndIsDeletedFalse(Long coderId);
    List<Encounter> findByStatusAndIsDeletedFalse(String status);
}
