package com.recyclexbackend.repository;

import com.recyclexbackend.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByUser_UserIdOrderByCreatedAtDesc(Long userId);
    List<Notification> findByUser_UserIdAndStatusOrderByCreatedAtDesc(Long userId, String status);
    long countByUser_UserIdAndStatus(Long userId, String status);
}
