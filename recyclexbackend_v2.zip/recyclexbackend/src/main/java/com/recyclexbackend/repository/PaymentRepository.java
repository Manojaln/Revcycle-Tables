package com.recyclexbackend.repository;

import com.recyclexbackend.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.math.BigDecimal;
import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findByClaim_ClaimId(Long claimId);

    @Query("SELECT COALESCE(SUM(p.insurancePayment), 0) FROM Payment p")
    BigDecimal sumInsurancePayments();

    @Query("SELECT COALESCE(SUM(p.patientPayment), 0) FROM Payment p")
    BigDecimal sumPatientPayments();

    @Query("SELECT COALESCE(SUM(p.adjustmentAmount), 0) FROM Payment p")
    BigDecimal sumAdjustments();
}
