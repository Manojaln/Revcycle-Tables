package com.recyclexbackend.repository;

import com.recyclexbackend.entity.CptMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CptMasterRepository extends JpaRepository<CptMaster, String> {
    List<CptMaster> findByIsActiveTrue();
    List<CptMaster> findByDescriptionContainingIgnoreCase(String keyword);
}
