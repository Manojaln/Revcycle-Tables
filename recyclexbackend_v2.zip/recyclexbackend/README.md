# 🏥 ReCycleX – Hospital Revenue Cycle Management Backend

A complete Spring Boot backend for the ReCycleX Hospital RCM System with JWT authentication, Role-Based Access Control, async claim decision engine, and full audit logging.

---

## 🚀 Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | Spring Boot 3.2.5 |
| Security | Spring Security + JWT (jjwt 0.12.5) |
| ORM | Spring Data JPA + Hibernate |
| Database | MySQL 8+ |
| Build | Maven |
| Java | Java 17 |

---

## ⚙️ Setup Instructions

### 1. Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8+

### 2. Database Setup
```sql
CREATE DATABASE recyclexdb;
```

### 3. Configure `application.properties`
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/recyclexdb?createDatabaseIfNotExist=true
spring.datasource.username=YOUR_DB_USER
spring.datasource.password=YOUR_DB_PASSWORD
```

### 4. Run the Application
```bash
mvn spring-boot:run
```

The app will auto-create tables and seed initial data on first run.

### 5. Default Admin Credentials
```
Email:    admin@recyclexbackend.com
Password: Admin@123
```

---

## 👥 User Roles

| Role | Description |
|------|-------------|
| `ADMIN` | Full system access, manage users, config, audit logs |
| `FRONT_DESK` | Register patients, manage insurance |
| `DOCTOR` | Create encounters, add diagnosis notes |
| `MEDICAL_CODER` | Assign ICD/CPT codes, capture charges |
| `BILLER` | Generate and submit claims |
| `PAYMENT_POSTER` | Record payments |
| `DENIAL_ANALYST` | Review and manage denied claims |

---

## 🔐 Authentication

All endpoints (except `/api/auth/**`) require a Bearer JWT token.

**Login:**
```
POST /api/auth/login
{
  "email": "admin@recyclexbackend.com",
  "password": "Admin@123"
}
```

Use the returned `token` as: `Authorization: Bearer <token>`

---

## 📋 Complete API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login & get JWT |

### Admin (ADMIN only)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/admin/users` | Create user |
| GET | `/api/admin/users` | Get all users |
| GET | `/api/admin/users/{id}` | Get user by ID |
| PATCH | `/api/admin/users/{id}/toggle-active` | Enable/disable user |
| GET | `/api/admin/users/role/{roleName}` | Get users by role |
| POST | `/api/admin/payers` | Create payer (insurance company) |
| GET | `/api/admin/payers` | Get all payers |
| PUT | `/api/admin/config/{key}` | Update system config |
| GET | `/api/admin/config` | Get all configs |
| GET | `/api/admin/audit-logs` | Get recent audit logs |
| GET | `/api/admin/audit-logs/entity/{type}/{id}` | Get logs by entity |

### Patients (FRONT_DESK, DOCTOR, BILLER, ADMIN)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/patients` | Register new patient |
| GET | `/api/patients` | Get all patients |
| GET | `/api/patients/{id}` | Get patient by ID |
| PUT | `/api/patients/{id}` | Update patient |
| DELETE | `/api/patients/{id}` | Soft delete patient |
| POST | `/api/patients/insurance` | Add insurance to patient |
| GET | `/api/patients/{patientId}/insurance` | Get patient's insurance |

### Encounters (DOCTOR, MEDICAL_CODER, BILLER, ADMIN)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/encounters` | Create encounter |
| GET | `/api/encounters` | Get all encounters |
| GET | `/api/encounters/{id}` | Get encounter by ID |
| GET | `/api/encounters/patient/{patientId}` | Get by patient |
| GET | `/api/encounters/my` | Get my encounters |
| PATCH | `/api/encounters/{id}/status?status=CODED` | Update encounter status |

### Charges (MEDICAL_CODER, ADMIN)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/charges` | Add charge entry |
| GET | `/api/charges/encounter/{encounterId}` | Get charges for encounter |
| DELETE | `/api/charges/{chargeId}` | Delete a charge |
| GET | `/api/charges/icd?keyword=` | Search ICD codes |
| GET | `/api/charges/cpt?keyword=` | Search CPT codes |

### Claims (BILLER, PAYMENT_POSTER, DENIAL_ANALYST, ADMIN)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/claims` | Create claim from encounter |
| POST | `/api/claims/{id}/submit` | Submit claim for adjudication |
| GET | `/api/claims` | Get all claims |
| GET | `/api/claims/{id}` | Get claim by ID |
| GET | `/api/claims/status/{status}` | Get by status (DRAFT/SUBMITTED/APPROVED/DENIED/PAID) |
| GET | `/api/claims/my` | Get my assigned claims |
| GET | `/api/claims/{id}/edits` | Get claim scrubber edits |
| GET | `/api/claims/{id}/history` | Get claim status history |

### Payments (PAYMENT_POSTER, ADMIN)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/payments` | Record payment for approved claim |
| GET | `/api/payments/claim/{claimId}` | Get payments for claim |

### Denials (DENIAL_ANALYST, ADMIN)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/denials` | Record a denial |
| GET | `/api/denials` | Get all denials |
| GET | `/api/denials/claim/{claimId}` | Get denials for claim |
| GET | `/api/denials/my` | Get my assigned denials |
| PATCH | `/api/denials/{id}/status?status=REVIEWED` | Update denial status |

### Dashboard (ADMIN, BILLER, DENIAL_ANALYST, PAYMENT_POSTER)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/dashboard` | Get financial & claim metrics |

### Notifications (All authenticated users)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/notifications` | Get my notifications |
| GET | `/api/notifications/unread-count` | Get unread count |
| PATCH | `/api/notifications/{id}/read` | Mark as read |

---

## 🔄 Application Workflow

```
1. FRONT_DESK → Register Patient + Add Insurance
2. DOCTOR → Create Encounter (status: OPEN)
3. MEDICAL_CODER → Add Charge Entries (ICD + CPT codes)
                 → Encounter auto-transitions to CODED
4. BILLER → Create Claim from Encounter
          → Claim Scrubber validates claim
          → Submit Claim (status: SUBMITTED)
5. SCHEDULER → Runs every 5 min, processes due claims
             → Simulates APPROVED (70%) or DENIED (30%)
6a. APPROVED → PAYMENT_POSTER records payment → PAID
6b. DENIED   → DENIAL_ANALYST records denial, reviews
7. ADMIN → Monitor Dashboard, Audit Logs
```

---

## ⚡ Async Claim Decision Engine

Claims are adjudicated asynchronously after a configurable delay (default: 24 hours).

**Change the delay via Admin API:**
```
PUT /api/admin/config/CLAIM_DECISION_DELAY_MS
Body: "60000"  (1 minute for testing)
```

The scheduler polls every 5 minutes for due claims and decides APPROVED or DENIED.

---

## 🛡️ Claim Scrubber Rules

Before a claim can be submitted, it goes through validation:

| Rule | Severity |
|------|----------|
| No charge entries exist | ERROR |
| Patient has no insurance | ERROR |
| Billed amount is zero | ERROR |
| ICD code is inactive | WARNING |
| CPT code is inactive | WARNING |

Claims with `ERROR` severity edits **cannot be submitted**.

---

## 📊 Dashboard Metrics

- Total billed amount
- Total insurance payments
- Total patient payments
- Total adjustments
- Claim counts by status
- Denial rate percentage
- Denial breakdown by reason code
- Denial breakdown by category
