package com.recyclexbackend.controller;

import com.recyclexbackend.dto.request.ClaimRequest;
import com.recyclexbackend.dto.response.ApiResponse;
import com.recyclexbackend.dto.response.ClaimResponse;
import com.recyclexbackend.entity.ClaimEdit;
import com.recyclexbackend.entity.ClaimStatusHistory;
import com.recyclexbackend.repository.ClaimEditRepository;
import com.recyclexbackend.repository.ClaimStatusHistoryRepository;
import com.recyclexbackend.service.ClaimService;
import com.recyclexbackend.util.SecurityHelper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/claims")
@RequiredArgsConstructor
public class ClaimController {

    private final ClaimService claimService;
    private final ClaimEditRepository claimEditRepository;
    private final ClaimStatusHistoryRepository claimStatusHistoryRepository;
    private final SecurityHelper securityHelper;

    @PostMapping
    public ResponseEntity<ApiResponse<ClaimResponse>> createClaim(@Valid @RequestBody ClaimRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Claim created",
                claimService.createClaim(request, securityHelper.getCurrentUserId())));
    }

    @PostMapping("/{id}/submit")
    public ResponseEntity<ApiResponse<ClaimResponse>> submitClaim(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Claim submitted",
                claimService.submitClaim(id, securityHelper.getCurrentUserId())));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<ClaimResponse>>> getAllClaims() {
        return ResponseEntity.ok(ApiResponse.success(claimService.getAllClaims()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ClaimResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(claimService.getById(id)));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse<List<ClaimResponse>>> getByStatus(@PathVariable String status) {
        return ResponseEntity.ok(ApiResponse.success(claimService.getByStatus(status)));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<ClaimResponse>>> getMyClaims() {
        return ResponseEntity.ok(ApiResponse.success(
                claimService.getByBiller(securityHelper.getCurrentUserId())));
    }

    @GetMapping("/{id}/edits")
    public ResponseEntity<ApiResponse<List<ClaimEdit>>> getClaimEdits(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(claimEditRepository.findByClaim_ClaimId(id)));
    }

    @GetMapping("/{id}/history")
    public ResponseEntity<ApiResponse<List<ClaimStatusHistory>>> getClaimHistory(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(
                claimStatusHistoryRepository.findByClaim_ClaimIdOrderByChangedAtDesc(id)));
    }
}
