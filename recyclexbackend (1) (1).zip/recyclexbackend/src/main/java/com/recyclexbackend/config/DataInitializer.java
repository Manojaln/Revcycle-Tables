package com.recyclexbackend.config;

import com.recyclexbackend.entity.*;
import com.recyclexbackend.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    private final IcdMasterRepository icdMasterRepository;
    private final CptMasterRepository cptMasterRepository;
    private final SystemConfigRepository systemConfigRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        seedRoles();
        seedAdminUser();
        seedIcdCodes();
        seedCptCodes();
        seedSystemConfig();
        log.info("Data initialization complete.");
    }

    private void seedRoles() {
        if (roleRepository.count() == 0) {
            roleRepository.save(new Role(1L, "ADMIN", LocalDateTime.now()));
            roleRepository.save(new Role(2L, "FRONT_DESK", LocalDateTime.now()));
            roleRepository.save(new Role(3L, "DOCTOR", LocalDateTime.now()));
            roleRepository.save(new Role(4L, "MEDICAL_CODER", LocalDateTime.now()));
            roleRepository.save(new Role(5L, "BILLER", LocalDateTime.now()));
            roleRepository.save(new Role(6L, "PAYMENT_POSTER", LocalDateTime.now()));
            roleRepository.save(new Role(7L, "DENIAL_ANALYST", LocalDateTime.now()));
            log.info("Roles seeded.");
        }
    }

    private void seedAdminUser() {
        if (!userRepository.existsByEmail("admin@recyclexbackend.com")) {
            Role adminRole = roleRepository.findByRoleName("ADMIN").orElseThrow();
            User admin = new User();
            admin.setName("System Admin");
            admin.setEmail("admin@recyclexbackend.com");
            admin.setPassword(passwordEncoder.encode("Admin@123"));
            admin.setRole(adminRole);
            admin.setIsActive(true);
            admin.setCreatedAt(LocalDateTime.now());
            admin.setUpdatedAt(LocalDateTime.now());
            userRepository.save(admin);
            log.info("Admin user seeded: admin@recyclexbackend.com / Admin@123");
        }
    }

    private void seedIcdCodes() {
        if (icdMasterRepository.count() == 0) {
            icdMasterRepository.save(new IcdMaster("J06.9", "Acute upper respiratory infection", true));
            icdMasterRepository.save(new IcdMaster("I10", "Essential (primary) hypertension", true));
            icdMasterRepository.save(new IcdMaster("E11.9", "Type 2 diabetes mellitus without complications", true));
            icdMasterRepository.save(new IcdMaster("Z00.00", "Encounter for general adult medical examination", true));
            icdMasterRepository.save(new IcdMaster("M54.5", "Low back pain", true));
            icdMasterRepository.save(new IcdMaster("K21.0", "Gastro-esophageal reflux disease with esophagitis", true));
            icdMasterRepository.save(new IcdMaster("F32.9", "Major depressive disorder, single episode", true));
            icdMasterRepository.save(new IcdMaster("J45.909", "Unspecified asthma, uncomplicated", true));
            log.info("ICD codes seeded.");
        }
    }

    private void seedCptCodes() {
        if (cptMasterRepository.count() == 0) {
            cptMasterRepository.save(new CptMaster("99213", "Office or outpatient visit, established patient, level 3", new BigDecimal("150.00"), true));
            cptMasterRepository.save(new CptMaster("99214", "Office or outpatient visit, established patient, level 4", new BigDecimal("220.00"), true));
            cptMasterRepository.save(new CptMaster("99203", "Office or outpatient visit, new patient, level 3", new BigDecimal("200.00"), true));
            cptMasterRepository.save(new CptMaster("99204", "Office or outpatient visit, new patient, level 4", new BigDecimal("280.00"), true));
            cptMasterRepository.save(new CptMaster("93000", "Electrocardiogram, routine ECG", new BigDecimal("75.00"), true));
            cptMasterRepository.save(new CptMaster("71046", "Radiologic examination, chest, 2 views", new BigDecimal("120.00"), true));
            cptMasterRepository.save(new CptMaster("85025", "Complete CBC with automated differential WBC count", new BigDecimal("40.00"), true));
            cptMasterRepository.save(new CptMaster("80053", "Comprehensive metabolic panel", new BigDecimal("55.00"), true));
            cptMasterRepository.save(new CptMaster("99395", "Periodic comprehensive preventive medicine re-evaluation, 18-39 yrs", new BigDecimal("250.00"), true));
            log.info("CPT codes seeded.");
        }
    }

    private void seedSystemConfig() {
        if (systemConfigRepository.count() == 0) {
            SystemConfig config = new SystemConfig();
            config.setConfigKey("CLAIM_DECISION_DELAY_MS");
            config.setConfigValue("86400000"); // 24 hours
            config.setUpdatedAt(LocalDateTime.now());
            systemConfigRepository.save(config);
            log.info("System config seeded.");
        }
    }
}
