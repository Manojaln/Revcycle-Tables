package com.recyclexbackend.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ClaimRequest {
    @NotNull
    private Long encounterId;

    @NotNull
    private Long payerId;

    private Long assignedBillerId;
}
